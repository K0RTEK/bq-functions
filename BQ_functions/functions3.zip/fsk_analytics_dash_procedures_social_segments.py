import re

def fsk_analytics_dash_procedures_social_segments(ad_name):
    ad_name_lower = ad_name.lower()
    if re.search(r'mktr|maketrue', ad_name_lower):
        return 'Maketrue'
    elif re.search(r'amdt', ad_name_lower):
       return 'Amberdata'
    elif re.search(r'konnektu|tec-', ad_name_lower):
       return 'CDP'
    elif re.search(r'lal|vco-special', ad_name_lower):
       return 'LAL'
    elif re.search(r'ret|open-lead-cpc|positive', ad_name_lower):
       return 'Retargeting'
    elif re.search(r'dmp|gorod-nedvizh', ad_name_lower):
       return 'DMP'
    elif re.search(r'keys', ad_name_lower):
       return 'Keys'
    elif re.search(r'dinrem|prospe.ting', ad_name_lower):
       return 'Dinrem'
    elif re.search(r'regions', ad_name_lower):
       return 'Regions'
    elif re.search(r'groups', ad_name_lower):
       return 'Group'
    elif re.search(r'apple|a(u|v)to|business|remont|dosug|employer|family|finance|geotag|income|interest|invest|ipoteka|job|leisure|naruzh|new-buil|newbuil|owner|parents|professions|realty|repair|socdem|supergeo|travel|villa|vklady|sport|highinc|interior|bus-edu|gorodskaya-nedv|luxury|inftec|beauty', ad_name_lower):
       return 'Interests'
    return None