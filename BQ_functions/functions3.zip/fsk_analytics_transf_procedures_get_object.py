import re

def fsk_analytics_transf_procedures_get_object(parameter: str) -> str:
    param_lower = parameter.lower()

    # Костыль Flatoutlet
    if re.search(r'flatoutlet|nearby', param_lower) and re.search(r'cpa|сра', param_lower):
        return 'Бренд ФСК'

    # MGCom
    if re.search(r'vskr|voskresensko|voskresensk|воскресенском|воскресенский', param_lower):
        return 'Дом на Воскресенском'
    elif re.search(r'druzhba|дружб', param_lower):
       return 'Дружба'
    elif re.search(r'zhavoron|жаворонки', param_lower):
       return 'Жаворонки Клаб'
    elif re.search(r'i.ma.lovsk|измайловск|монтажная.*8', param_lower):
       return '1-й Измайловский'
    elif re.search(r'comm|novogir|moskovsk|коммер', param_lower):
       return 'Коммерческая'
    elif re.search(r'martem|мартем', param_lower):
       return 'Мартемьяново Клаб'
    elif re.search(r'mld|molodezhn|молод.жный|калуга|kaluga.18', param_lower):
       return 'Молодежный'
    elif re.search(r'nstr|nastr|настроение', param_lower):
       return 'Настроение'
    elif re.search(r'olp|olimp|олимп', param_lower):
       return 'Олимп'
    elif re.search(r'aprel|парк апрель', param_lower):
       return 'Парк Апрель'
    elif re.search(r'pokolen|pkl|поколение', param_lower):
       return 'Поколение'
    elif re.search(r'rezh|режисс.р', param_lower):
       return 'Режиссер'
    elif re.search(r'_rim|rimsk|римский|развилка| rim ', param_lower):
       return 'Римский'
    elif re.search(r'rih|rikh|rixard|рихард', param_lower):
       return 'Рихард'
    elif re.search(r'saburovo|сабурово|сабурбер', param_lower):
       return 'Сабурово Клаб'
    elif re.search(r'sidn.*prime|sydn.*prime|сидней прайм', param_lower):
       return 'Сидней Прайм'
    elif re.search(r'sidn|sydn|sydey|сидней', param_lower):
       return 'Сидней Сити'
    elif re.search(r'simonovsk|симоновск', param_lower):
       return 'Симоновский'
    elif re.search(r'garden|гарден', param_lower):
       return 'Скай Гарден'
    elif re.search(r'skolkovsk|skl| sk |сколк', param_lower):
       return 'Сколковский'
    elif re.search(r'himkinsk|химкинский', param_lower):
       return '1-й Химкинский'
    elif re.search(r'centraln|центральный', param_lower):
       return 'Центральный'
    elif re.search(r'sheremet|шеремет', param_lower):
       return '1-й Шереметьевский'
    elif re.search(r'lake|лэйк', param_lower):
        return 'The Lake'

    # НЕ MGCom
    if re.search(r'zoom', param_lower) and re.search(r'hotel|отель', param_lower):
        return 'Best Western Zoom Hotel'
    elif re.search(r'м-хаус|мхаус', param_lower):
       return 'М-House'
    elif re.search(r'zoom', param_lower) and re.search(r'нев', param_lower):
       return 'Zoom на Неве'
    elif re.search(r'zoom', param_lower) and re.search(r'ч.рн', param_lower):
       return 'Zoom Черная речка'
    elif re.search(r'admiral|адмирал', param_lower):
       return 'Адмирал'
    elif re.search(r'amber|амбер', param_lower):
       return 'Амбер Сити'
    elif re.search(r'archite.t|arhite.t|архитектор', param_lower):
       return 'Архитектор'
    elif re.search(r'белая дача', param_lower):
       return 'Белая Дача'
    elif re.search(r'владивосток', param_lower) and re.search(r'крылова', param_lower):
       return 'Владивосток, Крылова 10'
    elif re.search(r'владивосток', param_lower) and re.search(r'философия', param_lower):
       return 'Владивосток, Философия'
    elif re.search(r'gagar.nsk|гагаринский', param_lower):
       return 'Гагаринский'
    elif re.search(r'datsk|датский', param_lower):
       return 'Датский квартал'
    elif re.search(r'govorovo|говорово', param_lower):
       return 'Движение Говорово'
    elif re.search(r'dvijen|dvizhen|движение|тушино.*2018', param_lower) and re.search(r'hotel|отель', param_lower):
       return 'Движение Апарт-отель'
    elif re.search(r'dvijen|dvizhen|движение|тушино.*2018', param_lower) and not re.search(r'продвижение', param_lower):
       return 'Движение'
    elif re.search(r'domodedovo|домодедово', param_lower):
       return 'Домодедово Парк'
    elif re.search(r'donsko|донской', param_lower):
       return '1-й Донской'
    elif re.search(r'dyh_|dyhan|дыхание', param_lower):
       return 'Дыхание'
    elif re.search(r'западное кунцево', param_lower):
       return 'Западное Кунцево'
    elif re.search(r'zarech|заречн', param_lower):
       return 'Заречный квартал'
    elif re.search(r'зеленодольск.*октябрьский', param_lower):
       return 'Зеленодольск, п. Октябрьский'
    elif re.search(r'зодиак', param_lower):
       return 'Зодиак'
    elif re.search(r'квартал 29', param_lower):
       return 'Квартал 29'
    elif re.search(r'кожухово', param_lower):
       return 'Кожухово паркинг'
    elif re.search(r'komendant|комендант', param_lower):
       return 'Комендантский'
    elif re.search(r'мосаэро', param_lower):
       return 'Мосаэро'
    elif re.search(r'moskvoreck|москворецк', param_lower):
       return 'Москворецкий'
    elif re.search(r'moskovsk|московск', param_lower) and not re.search(r'nov|new|новый', param_lower):
       return 'Московский'
    elif re.search(r'мфс пик', param_lower):
       return 'МФС ПИК'
    elif re.search(r'мясницкая', param_lower):
       return 'Мясницкая, д.13'
    elif re.search(r'naberezhn|набережн', param_lower):
       return 'На набережной. Орехово-Зуево'
    elif re.search(r'kagan|каган', param_lower):
       return 'На улице Кагана'
    elif re.search(r'nekrasov|некрасовка', param_lower):
       return 'Некрасовка'
    elif re.search(r'новая пролетарка', param_lower):
       return 'Новая Пролетарка'
    elif re.search(r'novogireevsk|новогиреевский', param_lower):
       return 'Новогиреевский'
    elif re.search(r'i.ma.lovo|новое измайлово', param_lower):
       return 'Новое Измайлово'
    elif re.search(r'novoetushino|novoe(-| )tushino|новое тушино', param_lower):
       return 'Новое Тушино'
    elif re.search(r'moskovsk|московск', param_lower):
       return 'Новый Московский'
    elif re.search(r'ramensk|раменский', param_lower):
       return 'Новый Раменский'
    elif re.search(r'andreevsk|андреевский', param_lower):
       return 'Первый Андреевский'
    elif re.search(r'leningradsk|lerningradsk|ленинградский|молжаниново|1-len', param_lower):
       return 'Первый Ленинградский'
    elif re.search(r'лермонтовский|lerm', param_lower):
       return 'Первый Лермонтовский'
    elif re.search(r'юбилейный', param_lower):
       return 'Первый Юбилейный'
    elif re.search(r'программы урвн', param_lower):
       return 'Программы УРВН'
    elif re.search(r'pushkinsk|пушкинск', param_lower):
       return 'Пушкинский'
    elif re.search(r'путилково', param_lower):
       return 'Путилково (ДСК)'
    elif re.search(r'rotterdam|роттердам', param_lower):
       return 'Роттердам'
    elif re.search(r'саларьево', param_lower):
       return 'Саларьево'
    elif re.search(r'саларьевский', param_lower):
       return '1-й Саларьевский'
    elif re.search(r'svetlanovsk|светлановск', param_lower):
       return 'Светлановский'
    elif re.search(r'skand|скандинавский', param_lower):
       return 'Скандинавский'
    elif re.search(r'solncevo|солнцево', param_lower):
       return 'Солнцево'
    elif re.search(r'столичный квартал', param_lower):
       return 'Столичный квартал'
    elif (re.search(r'flagman|флагман', param_lower) and re.search(r'vladivost|владивосток|горшкова', param_lower)) or re.search(r'владивосток.*горшкова', param_lower):
       return 'Флагман Владивосток'
    elif re.search(r'flagman|флагман|раменское', param_lower):
       return 'Флагман'
    elif re.search(r'форест', param_lower):
       return 'ФоРест'
    elif re.search(r'centr(_|.2|2)|центр(.2|2)', param_lower):
       return 'Центр-2'
    elif re.search(r'bit.a|битца', param_lower):
       return 'Южная Битца'
    elif re.search(r'южное кучино', param_lower):
       return 'Южное Кучино-2'
    elif re.search(r'uzhn|южный', param_lower):
       return '1-й Южный'
    elif re.search(r'asenevsk|asenesk|ясеневский|мамыри', param_lower):
       return '1-й Ясеневский'
    elif re.search(r'^up$', param_lower):
        return 'UP'

    # ФСК и ДСК Бренды
    if re.search(r'btl|бтл', param_lower):
        return 'Движение BTL'
    elif re.search(r'вторич', param_lower):
       return 'Вторичная недвижимость'
    elif re.search(r'кладовые', param_lower):
       return 'Кладовые'
    elif re.search(r'машиноместа', param_lower):
       return 'Машиноместа'
    elif re.search(r'realist|реалист', param_lower):
       return 'Реалист'
    elif re.search(r'спецпроект', param_lower):
       return 'Спецпроект'
    elif re.search(r'трейд-ин', param_lower):
       return 'Трейд-Ин'
    elif re.search(r'business|бизнес', param_lower) and not re.search(r'outlet|аутлет', param_lower):
       return 'Бизнес ФСК'
    elif re.search(r'fsk(_|-)olv|olv.*fsk|brand.*olv|бренд фск.*olv|бренд olv', param_lower):
       return 'Бренд ФСК OLV'
    elif re.search(r'fsk-outlet|аутлет', param_lower):
       return 'ФСК Аутлет'
    elif re.search(r'brand|_fsk_|soc_fsk-|fsk lider|fsk.*недвижимость|fsk.*ретаргетинг|бренд фск|fsk.*ipoteka|фск.*лидер|фск', param_lower) and not re.search(r'dsk|дск', param_lower):
       return 'Бренд ФСК'
    elif re.search(r'застройщика|zastroishchika|zastroishchik-gk-fsk', param_lower):
       return 'Бренд ФСК'
    elif (re.search(r'(_| |-)dsk|dsk(_| |-)| дск|дск |дск-1|дск1', param_lower) or param_lower == 'dsk') and not re.search(r'olv|bitca', param_lower):
       return 'Бренд ДСК'
    elif re.search(r'dsk|дск', param_lower) and re.search(r'olv', param_lower):
        return 'Бренд ДСК OLV'

    return 'NaN'

