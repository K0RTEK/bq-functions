import re

def akvilon_analytics_agg_procedures_get_call_tags(call_tags):
    return ','.join(re.findall(r'"names":\[(.+?)\]', call_tags))
