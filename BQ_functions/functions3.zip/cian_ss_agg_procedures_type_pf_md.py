import re

def cian_ss_agg_procedures_type_pf_md(campaign_name, ad_name, campaign_id):
    if re.search(r'^pf|_pf_|_pf$', campaign_name.lower()) or re.search(r'^pf|_pf_|_pf$', ad_name.lower()):
        return 'Перформ'
    elif re.search(r'^md|_md_|_md$|^report_|_report_|_report$', campaign_name.lower()) or re.search(r'^md|_md_|_md$|^report_|_report_|_report$', ad_name.lower()):
        return 'Медийка'
    return "Перформ"