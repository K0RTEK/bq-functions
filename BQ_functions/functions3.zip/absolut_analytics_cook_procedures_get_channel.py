import re


def absolut_analytics_cook_procedures_get_channel(calltracking, traffic_source, source_engine, direct_click_order, utm_source, utm_medium, utm_campaign,
                utm_content, utm_term):
    combined = "_".join(
        [calltracking or "", utm_source or "", utm_medium or "", utm_campaign or "", utm_content or "", utm_term or ""])

    if re.search(r'((atommedia).*(call|cpa|лидоген|звон|fid))', combined, re.IGNORECASE):
        return "Лидогенерация"
    if re.search(r'yandex', utm_source, re.IGNORECASE) and re.search(r'cpc|cpm', utm_medium, re.IGNORECASE):
        return 'Яндекс Директ'
    if re.search(r'google', utm_source, re.IGNORECASE) and re.search(r'cpc', utm_medium, re.IGNORECASE):
        return 'Google Ads'
    if traffic_source == 'Search engine traffic' and utm_source is None and utm_medium is None:
        return 'Поисковые системы'
    if re.search(r'vk_ads|vk_reklama|vk$', utm_source, re.IGNORECASE):
        return 'Реклама в соц.сетях'
    if re.search(r'фид|домклик', calltracking, re.IGNORECASE):
        return 'Базы недвижимости'
    return None
