import re

def fsk_analytics_analytics_raw_trackings_get_phone_leads(phone):
    # Удаляем все буквы и пробелы из строки
    cleaned_phone = re.sub(r'[а-яёa-z ]', '', phone.lower())

    # Применяем те же правила, что и в SQL CASE
    if len(cleaned_phone) == 11 and cleaned_phone[:2] in ('84', '89'):
        return '7' + cleaned_phone[-10:]
    elif len(cleaned_phone) == 10:
        return '7' + cleaned_phone
    elif len(cleaned_phone) == 12 and phone.startswith('77'):
        return cleaned_phone[-11:]
    elif len(cleaned_phone) == 12 and phone.startswith('789'):
        return '7' + cleaned_phone[-10:]
    elif len(cleaned_phone) > 12 and phone.startswith('79'):
        return cleaned_phone[:11]
    else:
        return cleaned_phone

# Пример использования функции
print(fsk_analytics_analytics_raw_trackings_get_phone_leads('84 1234567890'))  # Вернет: 71234567890
print(fsk_analytics_analytics_raw_trackings_get_phone_leads('1234567890'))     # Вернет: 71234567890
print(fsk_analytics_analytics_raw_trackings_get_phone_leads('771234567890'))   # Вернет: 1234567890
print(fsk_analytics_analytics_raw_trackings_get_phone_leads('7891234567890'))  # Вернет: 71234567890
print(fsk_analytics_analytics_raw_trackings_get_phone_leads('791234567890123'))# Вернет: 79123456789
print(fsk_analytics_analytics_raw_trackings_get_phone_leads('Some text 123'))  # Вернет: 123
