import re

def forma_analytic_raw_procedures_get_phone(str_field):
    return re.sub(r'\..*|[^0-9]', '', str_field)