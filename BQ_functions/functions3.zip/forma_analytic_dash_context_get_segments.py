import re

def forma_analytic_dash_context_get_segments(date, campaign_name):
    if re.search(r'визитка.*бренд', campaign_name.lower()):
        return ['Бренд', 'Бренд', 'Визитка Бренд', 'Поиск']
    elif re.search(r'визитка.*не(|.*)бренд', campaign_name.lower()):
        return ['НеБренд', 'НеБренд', 'Визитка НеБренд', 'Поиск']
    else:
        return None