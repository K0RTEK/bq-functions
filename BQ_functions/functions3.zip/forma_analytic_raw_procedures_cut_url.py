import re

def forma_analytic_raw_procedures_cut_url(url, part):
    clean_url = re.sub(r'($|&|=)', 'S', url.strip().lower())
    clean_url = re.sub(r'utm_sourceSS|utm_mediumSS|utm_campaignSS|utm_contentSS|utm_termSS', '', clean_url)
    match = re.search(fr'{part}S(.+?)S', clean_url)
    return match.group(1) if match else 'None'