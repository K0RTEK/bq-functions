import re

def fsk_analytics_cook_procedures_get_client(object):
    object_lower = object.lower()
    if re.search(r'южная битца|(первый|1).*ленинградский|(первый|1).*лермонтовский|донской|шереметьевский|южный|ясеневский|измайловский|химкинский', object_lower):
        return 'ДСК'
    elif re.search(r'олимп|дружба|молод.жный', object_lower):
        return 'ФСК Калуга'
    elif re.search(r'настроение|новый раменский|скай гарден|sky garden|skygarden|сколковский|спецпроект|роттердам|rotterdam|сидней сити|s.dney city|архитектор|датский квартал|режисс.р|римский|рихард|скандинавский|движение|жк для номера на лендинге|апрель|lake|сабурово|жаворонки|prime|прайм', object_lower):
        return 'ФСК'
    return f'NaN - {object}'