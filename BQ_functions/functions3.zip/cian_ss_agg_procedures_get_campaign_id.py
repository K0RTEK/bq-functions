import re

def cian_ss_agg_procedures_get_campaign_id(source_medium, utm_campaign, utm_content, utm_term):
    if re.search(r'mytarget', source_medium.lower()):
        return re.search(r'[0-9]{6,}', utm_campaign).group(0)
    elif re.search(r'vk ', source_medium.lower()):
        return re.search(r'[0-9]{6,}', utm_campaign).group(0)
    elif re.search(r'vkr', source_medium.lower()):
        return re.search(r'[0-9]{6,}', utm_campaign).group(0)
    elif re.search(r'yandex / cpc', source_medium.lower()):
        return re.search(r'[0-9]{6,}', utm_campaign).group(0)
    else:
        return 'NaN'