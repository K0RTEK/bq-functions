def akvilon_analytics_agg_procedures_get_target_call_crm(crm_target_call, crm_source, utm_referrer, communication_id):
    if crm_target_call and (crm_source == "Реклама застройщика" or utm_referrer == 'https://indy-towers.ru') and (communication_id == "" or communication_id is None):
        return True
    elif crm_target_call and communication_id not in ("", None) and crm_source != "Самоход":
        return True
    return False
