import re

def center_invest_analytics_cook_context_yandex_get_device(date, utm_source, utm_medium, utm_campaign, utm_content, utm_term):
    if re.search(r'dt:m|dvc:m', utm_term) or re.search(r'dt:m|dvc:m', utm_content):
        return 'mobile'
    elif re.search(r'dt:t|dvc:t', utm_term) or re.search(r'dt:t|dvc:t', utm_content):
        return 'tablet'
    elif re.search(r'dt:c|desktop', utm_term) or re.search(r'dt:c|desktop', utm_content):
        return 'desktop'
    return None