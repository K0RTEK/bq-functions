import re


def fsk_analytics_procedures_get_object_campaign(channel: str, campaign: str) -> str:
    if channel == 'Реклама в соц.сетях':
        if re.search(r'dvijen|dvizhen|движение', campaign.lower()) and re.search(r'btl', campaign.lower()):
            return 'Движение BTL'
        elif re.search(r'archite.t|arhite.t|архитектор', campaign.lower()):
           return 'Архитектор'
        elif re.search(r'gagar.nsk|гагаринский', campaign.lower()):
           return 'Гагаринский'
        elif re.search(r'datsk|датский', campaign.lower()):
           return 'Датский квартал'
        elif re.search(r'dvijen|dvizhen|движение', campaign.lower()) and not re.search(r'btl|говорово|govorovo',
                                                                                    campaign.lower()):
           return 'Движение'
        elif re.search(r'govorovo|говорово', campaign.lower()):
           return 'Движение Говорово'
        elif re.search(r'domodedovo|домодедово', campaign.lower()):
           return 'Домодедово Парк'
        elif re.search(r'dyh_|dyhan|дыхание', campaign.lower()):
           return 'Дыхание'
        elif re.search(r'moskvoreck|москворецк', campaign.lower()):
           return 'Москворецкий'
        elif re.search(r'nekrasov|некрасовка', campaign.lower()):
           return 'Некрасовка'
        elif re.search(r'novogireevsk|новогиреевский', campaign.lower()):
           return 'Новогиреевский'
        elif re.search(r'novoetushino|novoe(-| )tushino|новое тушино', campaign.lower()):
           return 'Новое Тушино'
        elif re.search(r'ramensk|раменский', campaign.lower()):
           return 'Новый Раменский'
        elif re.search(r'andreevsk|андреевский', campaign.lower()):
           return 'Первый Андреевский'
        elif re.search(r'le(n|rn)ingradsk|ленинградский', campaign.lower()):
           return 'Первый Ленинградский'
        elif re.search(r'lermontovsk|лермонтовский|1-lerm', campaign.lower()):
           return 'Первый Лермонтовский'
        elif re.search(r'donsko|донской', campaign.lower()):
           return '1-й Донской'
        elif re.search(r'uzhniy|южный', campaign.lower()):
           return '1-й Южный'
        elif re.search(r'юбилейный', campaign.lower()):
           return 'Первый Юбилейный'
        elif re.search(r'rotterdam|роттердам', campaign.lower()):
           return 'Роттердам'
        elif re.search(r'skand|скандинавский', campaign.lower()):
           return 'Скандинавский'
        elif re.search(r'solncevo', campaign.lower()):
           return 'Солнцево'
        elif re.search(r'flagman|флагман', campaign.lower()):
           return 'Флагман'
        elif re.search(r'centr(_|.2|2)|центр(.2|2)', campaign.lower()):
           return 'Центр-2'
        elif re.search(r'bit.a|битца', campaign.lower()):
           return 'Южная Битца'
        elif re.search(r'(_| |-)dsk|dsk(_| |-)| дск|дск ', campaign.lower()) and not re.search(r'olv|bitca',
                                                                                            campaign.lower()):
           return 'Бренд ДСК'
        elif re.search(r'dsk|дск', campaign.lower()) and re.search(r'olv', campaign.lower()):
           return 'Бренд ДСК OLV'
        elif re.search(r'коммер|comm', campaign.lower()):
           return 'Коммерческая'
        elif re.search(r'voskresensk|воскресенском', campaign.lower()) and not re.search(r'centr|центр',
                                                                                      campaign.lower()):
           return 'Дом на Воскресенском'
        elif re.search(r'molodezhn|молод.жный', campaign.lower()):
           return 'Молодежный'
        elif re.search(r'nastroen|(-| |_)nstr|nstr(-| |_)|настроение', campaign.lower()):
           return 'Настроение'
        elif re.search(r'olimp|олимп', campaign.lower()):
           return 'Олимп'
        elif re.search(r'druzhba|дружба', campaign.lower()):
           return 'Дружба'
        elif re.search(r'lake', campaign.lower()):
           return 'The Lake'
        elif re.search(r'aprel|парк апрель', campaign.lower()):
           return 'Парк Апрель'
        elif re.search(r'zhavoronk|жаворонки', campaign.lower()):
           return 'Жаворонки Клаб'
        elif re.search(r'sheremet|шеремет', campaign.lower()):
           return '1-й Шереметьевский'
        elif re.search(r'pokolen|поколение', campaign.lower()):
           return 'Поколение'
        elif re.search(r'rezh|режис', campaign.lower()):
           return 'Режиссер'
        elif re.search(r'_rim|римский|rim_|rimsk', campaign.lower()):
           return 'Римский'
        elif re.search(r'rih|рихард', campaign.lower()):
           return 'Рихард'
        elif re.search(r'saburovo|сабурово', campaign.lower()):
           return 'Сабурово Клаб'
        elif re.search(r's.dn|сидней|sydey', campaign.lower()) and not re.search(r'-prime', campaign.lower()):
           return 'Сидней Сити'
        elif re.search(r's.dn.*-prime', campaign.lower()):
           return 'Сидней Прайм'
        elif re.search(r'skygarden|sky garden', campaign.lower()):
           return 'Скай Гарден'
        elif re.search(r'skl|skol|сколковский', campaign.lower()):
           return 'Сколковский'
        elif re.search(r'centraln.*voskr|центральный.*воскресенск', campaign.lower()):
           return 'Центральный Воскресенск'
        elif re.search(r'centraln.*noginsk|центральный.*ногинск', campaign.lower()):
           return 'Центральный Ногинск'
        elif re.search(r'realist|реалист', campaign.lower()):
           return 'Реалист'
        elif re.search(r'fsk|фск|brand|tec-00012', campaign.lower()) and not re.search(
               r'business|olv|dsk|brand-b|дск|outlet|аутлет', campaign.lower()):
           return 'Бренд ФСК'
        elif re.search(r'fsk|фск|brand|бренд', campaign.lower()) and re.search(r'olv', campaign.lower()):
           return 'Бренд ФСК OLV'
        elif re.search(r'fsk.*business|brand-b|бизнес', campaign.lower()) and not re.search(r'outlet', campaign.lower()):
           return 'Бизнес ФСК'
        elif re.search(r'fsk-outlet|аутлет', campaign.lower()):
            return 'ФСК Аутлет'
        return f'NaN - {campaign}'

    elif channel == 'Контекстная реклама':
        if re.search(r'dvijen|dvizhen|движение|бтл-дв|btl-dv', campaign.lower()) and re.search(r'btl|бтл',
                                                                                               campaign.lower()):
            return 'Движение BTL'
        if re.search(r'admiral|адмирал', campaign.lower()):
            return 'Адмирал'
        elif re.search(r'archite.t|arhite.t|архитектор', campaign.lower()):
           return 'Архитектор'
        elif re.search(r'gagar.nsk|гагаринский', campaign.lower()):
           return 'Гагаринский'
        elif re.search(r'datsk|датский', campaign.lower()):
           return 'Датский квартал'
        elif re.search(r'dvijen|dvizhen|движение', campaign.lower()) and not re.search(r'btl|говорово|govorovo',
                                                                                    campaign.lower()):
           return 'Движение'
        elif re.search(r'govorovo|говорово', campaign.lower()):
           return 'Движение Говорово'
        elif re.search(r'domodedovo|домодедово', campaign.lower()):
           return 'Домодедово Парк'
        elif re.search(r'dyh_|d(y|i)han|дыхание', campaign.lower()):
           return 'Дыхание'
        elif re.search(r'moskvoreck|москворецк', campaign.lower()):
           return 'Москворецкий'
        elif re.search(r'на-набережной', campaign.lower()):
           return 'На набережной'
        elif re.search(r'nekrasov|некрасовка', campaign.lower()):
           return 'Некрасовка'
        elif re.search(r'novogireevsk|новогиреевский|balash', campaign.lower()):
           return 'Новогиреевский'
        elif re.search(r'novoetushino|novoe(-| )tushino|новое тушино|tyshino', campaign.lower()):
           return 'Новое Тушино'
        elif re.search(r'ramensk|раменский', campaign.lower()):
           return 'Новый Раменский'
        elif re.search(r'andreev|андреевский', campaign.lower()):
           return 'Первый Андреевский'
        elif re.search(r'le(n|rn)ing(r|t)adsk|ленинградский', campaign.lower()):
           return 'Первый Ленинградский'
        elif re.search(r'ler(m|mm)ontovsk|лермонтовский|1-lerm', campaign.lower()):
           return 'Первый Лермонтовский'
        elif re.search(r'donsko|донской', campaign.lower()):
           return '1-й Донской'
        elif re.search(r'uzhniy|южный', campaign.lower()):
           return '1-й Южный'
        elif re.search(r'юбилейный|bile.n', campaign.lower()):
           return 'Первый Юбилейный'
        elif re.search(r'rotterdam|роттердам', campaign.lower()):
           return 'Роттердам'
        elif re.search(r'skand|скандинавский', campaign.lower()):
           return 'Скандинавский'
        elif re.search(r'flagman|флагман', campaign.lower()):
           return 'Флагман'
        elif re.search(r'centr(_|.2|2)|центр(.2|2)', campaign.lower()):
           return 'Центр-2'
        elif re.search(r'bit.a|битца', campaign.lower()):
           return 'Южная Битца'
        elif re.search(r'(_| |-)dsk|dsk(_| |-)| дск|дск ', campaign.lower()) and not re.search(r'olv|bitca|вдск',
                                                                                            campaign.lower()):
           return 'Бренд ДСК'
        elif re.search(r'dsk|дск', campaign.lower()) and re.search(r'olv', campaign.lower()):
           return 'Бренд ДСК OLV'
        elif re.search(r'коммер|comm', campaign.lower()):
           return 'Коммерческая'
        elif re.search(r'voskresensk|воскресенском', campaign.lower()) and not re.search(r'centr|центр',
                                                                                      campaign.lower()):
           return 'Дом на Воскресенском'
        elif re.search(r'дружба|druzhba', campaign.lower()):
           return 'Дружба'
        elif re.search(r'molodezhn|молод.жный', campaign.lower()):
           return 'Молодежный'
        elif re.search(r'nastroen|nstr_|настроение', campaign.lower()):
           return 'Настроение'
        elif re.search(r'olimp|олимп', campaign.lower()):
           return 'Олимп'
        elif re.search(r'lake', campaign.lower()):
           return 'The Lake'
        elif re.search(r'aprel|парк апрель', campaign.lower()):
           return 'Парк Апрель'
        elif re.search(r'zhavoron|жаворонки', campaign.lower()):
           return 'Жаворонки Клаб'
        elif re.search(r'1.shereme|1shereme|шереметьевский', campaign.lower()):
           return '1-й Шереметьевский'
        elif re.search(r'pokolen|pkl|поколение', campaign.lower()):
           return 'Поколение'
        elif re.search(r'rezh|режис', campaign.lower()):
           return 'Режиссер'
        elif re.search(r'rim_|rimsk|римский|развилка', campaign.lower()):
           return 'Римский'
        elif re.search(r'rih_|rihard|rikhard|рихард', campaign.lower()):
           return 'Рихард'
        elif re.search(r's.dn|сидней|sydey', campaign.lower()) and not re.search(r'-prime', campaign.lower()):
           return 'Сидней Сити'
        elif re.search(r's.dn.*-prime', campaign.lower()):
           return 'Сидней Прайм'
        elif re.search(r'сабурово|saburovo', campaign.lower()):
           return 'Сабурово Клаб'
        elif re.search(r'skygarden|sky garden|скай( г|г)арден', campaign.lower()):
           return 'Скай Гарден'
        elif re.search(r'skl_|_skl|skol|сколк', campaign.lower()):
           return 'Сколковский'
        elif re.search(r'centraln.*voskr|центральный.*воскресенск', campaign.lower()):
           return 'Центральный Воскресенск'
        elif re.search(r'centraln.*noginsk|центральный.*ногинск', campaign.lower()):
           return 'Центральный Ногинск'
        elif re.search(r'реалист|realist', campaign.lower()):
           return 'Реалист'
        elif re.search(r'fsk|фск|brand|brend|бренд|outlet|аутлет', campaign.lower()) and re.search(
               r'mg_ya_|mg \| контекст', campaign.lower()) and not re.search(r'business|olv|dsk|brand-b|дск',
                                                                             campaign.lower()):
           return 'Бренд ФСК'
        elif re.search(r'fsk|фск|brand|brend|бренд', campaign.lower()) and re.search(r'olv', campaign.lower()):
           return 'Бренд ФСК OLV'
        elif re.search(r'fsk.*business|бизнес|business-class', campaign.lower()) and not re.search(r'outlet',
                                                                                                campaign.lower()):
           return 'Бизнес ФСК'
        elif re.search(r'test', campaign.lower()) and not re.search(r'outlet', campaign.lower()):
            return 'Тест'
        return f'NaN - {campaign}'

    return 'NaN'
