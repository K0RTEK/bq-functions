import re

def center_invest_analytics_cook_context_yandex_get_position(date, utm_source, utm_medium, utm_campaign, utm_content, utm_term):
    return next((match for pattern in [r'\|p:(\d+)\|', r'%7cp:(\d+)%7c'] if (match := re.search(pattern, utm_content))), None)
