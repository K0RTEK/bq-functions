import re

def cian_ss_agg_procedures_get_keyword_id(source_medium, utm_campaign, utm_content, utm_term):
    if re.search(r'yandex / cpc', source_medium.lower()):
        match = re.search(r'kw:([0-9-]+)', utm_content.lower())
        return match.group(1) if match else 'NaN'
    return 'NaN'