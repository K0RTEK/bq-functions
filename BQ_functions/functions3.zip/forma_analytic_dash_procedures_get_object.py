import re

def forma_analytic_dash_procedures_get_object(ct_campaign_name, source, medium, campaign, content, term, campaign_name):
    if re.search(r'republic', ct_campaign_name.lower()):
        return 'Republic'
    elif re.search(r'republic', campaign.lower()) or re.search(r'republic', campaign_name.lower()):
        return 'Republic'
    else:
        return 'Undefined Object'