import re


def absolut_analytics_cook_procedures_get_object(parameter):
    parameter = parameter.lower()

    if re.search(r'moskov|москов|пм_', parameter):
        return 'Первый Московский'
    elif re.search(r'peredelk|переделк|пб_', parameter):
        return 'Переделкино Ближнее'
    # Add more conditions based on original SQL function
    return 'Неизвестный'
