import re

def center_invest_analytics_cook_procedures_get_call_duration(call_duration):
    match = re.search(r'..:..:(.*)', call_duration)
    if match and len(call_duration) > 8 or int(match.group(1)) >= 60:
        minutes = str(int(match.group(1)) // 60).zfill(2)
        seconds = str(int(match.group(1)) % 60).zfill(2)
        return f"00:{minutes}:{seconds}"
    return call_duration