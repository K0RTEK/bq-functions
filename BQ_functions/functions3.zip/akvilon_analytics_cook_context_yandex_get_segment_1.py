import re

def akvilon_analytics_cook_context_yandex_get_segment_1(campaign_name):
    if re.search(r'( |_|-|^)brand( |-|_|$)', campaign_name.lower()) and \
       not re.search(r'( |_|-|^)network( |-|_|$)', campaign_name.lower()):
        return 'Бренд'
    elif re.search(r'( |_|-|^)search( |-|_|$)|( |_|-|^)s( |-|_|$)', campaign_name.lower()) and \
         not re.search(r'(_|-|^)brand( |-|_|$)', campaign_name.lower()):
        return 'Поиск'
    elif re.search(r'( |_|-|^)performance( |-|_|$)', campaign_name.lower()) and \
         not re.search(r'Без исключений', campaign_name.lower()):
        return 'Мастер кампаний'
    elif re.search(r'( |_|-|^)mc( |-|_|$)', campaign_name.lower()) and \
         not re.search(r'Без исключений', campaign_name.lower()):
        return 'Мастер кампаний'
    elif re.search(r'( |_|-|^)tc( |-|_|$)|( |_|-|^)tg( |-|_|$)', campaign_name.lower()) and \
         not re.search(r'Без исключений', campaign_name.lower()):
        return 'Товарная кампания'
    elif re.search(r'( |_|-|^)визитка( |-|_|$)|(^|_| |-)vizitka( |-|_|$)', campaign_name.lower()) and \
         not re.search(r'Без исключений', campaign_name.lower()):
        return 'Визитка'
    elif re.search(r'( |_|-|^)network( |-|_|$)|( |_|-|^)n( |-|_|$)', campaign_name.lower()):
        return 'РСЯ'
    else:
        return 'Прочее'