import re

def fsk_analytics_agg_procedures_get_ad_id(date, channel, placement, utm_source, utm_medium, utm_campaign, utm_content, utm_term):
    utm_content_lower = utm_content.lower()
    utm_campaign_lower = utm_campaign.lower()
    if channel == 'Контекстная реклама' and placement == 'Яндекс Директ':
        if 'adid:' in utm_content_lower:
            return re.search(r'adid:([0-9]+)', utm_content_lower).group(1)
        if 'gid|' in utm_content_lower:
            return re.search(r'gid\|([0-9]+)', utm_content_lower).group(1)
        if 'b:' in utm_content_lower:
            return re.search(r'b:([0-9]+)', utm_content_lower).group(1)
        if 'aid|' in utm_content_lower:
            return re.search(r'aid\|([0-9]+)', utm_content_lower).group(1)
    elif channel == 'Реклама в соц.сетях':
        if placement == 'Facebook':
            if 'adid:' in utm_content_lower:
                return re.search(r'adid:([0-9]+)', utm_content_lower).group(1)
            elif re.search(r'([0-9]{5,})', utm_content_lower) and not 'adid:' in utm_content_lower:
                return re.search(r'([0-9]{5,})', utm_content_lower).group(1)
            elif re.search(r'([0-9]{5,})', utm_campaign_lower) and not utm_content:
                return re.search(r'([0-9]{5,})', utm_campaign_lower).group(1)
        elif placement == 'MyTarget':
            if 'adid:' in utm_content_lower:
                return re.search(r'adid:([0-9]+)', utm_content_lower).group(1)
            elif re.search(r'([0-9]{5,})', utm_content_lower) and not 'adid:' in utm_content_lower:
                return re.search(r'([0-9]{5,})', utm_content_lower).group(1)
            elif re.search(r'([0-9]{5,})', utm_campaign_lower) and not utm_content:
                return re.search(r'([0-9]{5,})', utm_campaign_lower).group(1)
        elif placement == 'Vkontakte':
            if 'adid:' in utm_content_lower:
                return re.search(r'adid:([0-9]+)', utm_content_lower).group(1)
            elif re.search(r'([0-9]{5,})', utm_content_lower) and not 'adid:' in utm_content_lower:
                return re.search(r'([0-9]{5,})', utm_content_lower).group(1)
            elif re.search(r'([0-9]{5,})', utm_campaign_lower) and not utm_content:
                return re.search(r'([0-9]{5,})', utm_campaign_lower).group(1)
    elif utm_source in ['vk_ads', 'vk_reklama'] and utm_medium in ['cpc', 'cpm']:
        if 'adid:' in utm_content_lower:
            return re.search(r'adid:([0-9]+)', utm_content_lower).group(1)
        elif re.search(r'([0-9]{5,})', utm_content_lower) and not 'adid:' in utm_content_lower:
            return re.search(r'([0-9]{5,})', utm_content_lower).group(1)
    return None