import re

def center_invest_analytics_cook_context_yandex_get_banner_id(date, utm_source, utm_medium, utm_campaign, utm_content, utm_term):
    if utm_source is None:
        return re.search(r'\(M-(\d+)\)$', utm_content).group(1) if re.search(r'\(M-(\d+)\)$', utm_content) else None
    return next((match for pattern in [
        r'\|b:(\d+)\|', r'\|aid\|(\d+)', r'\|aid:(\d+)', r'%7cb:(\d+)%7c', r'%7caid%7c(\d+)%7c']
        if (match := re.search(pattern, utm_content))), None)