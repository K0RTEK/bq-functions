import re

def restore_inventive_analytics_procedures_social_platform(campaign):
    campaign = campaign.lower()
    if re.search(r'cross|pf_m_dir_dnmc|pf_m_ret_dnmc_action', campaign):
        return 'Все устройства'
    elif re.search(r'mob_', campaign):
        return 'Мобилка'
    elif re.search(r'web_', campaign):
        return 'Веб'
    else:
        return 'NaN'
