import re

def akvilon_analytics_cook_context_yandex_get_source_type(date, utm_source, utm_medium, utm_campaign, utm_content, utm_term):
    if re.search(r'src\|context|st\|context', utm_term.lower()) or \
       re.search(r'src\|context|st\|context', utm_content.lower()):
        return 'ad_network'
    elif re.search(r'src\|search|st\|search', utm_term.lower()) or \
         re.search(r'src\|search|st\|search', utm_content.lower()):
        return 'search'