import re

def center_invest_analytics_cook_context_yandex_get_retargeting_id(date, utm_source, utm_medium, utm_campaign, utm_content, utm_term):
    patterns = [r're:(\d+)\|', r'\|re\|(\d+)\|', r'%7cre\|(\d+)\%7c']
    return next((match for pattern in patterns if (match := re.search(pattern, utm_content))), None)
