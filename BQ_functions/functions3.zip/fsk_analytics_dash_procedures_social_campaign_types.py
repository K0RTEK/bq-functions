import re

def fsk_analytics_dash_procedures_social_campaign_types(campaign_global):
    campaign_lower = campaign_global.lower()
    if re.search(r'magazin', campaign_lower):
        return 'Magazin'
    elif re.search(r'chat-landing', campaign_lower):
       return 'Chat-landing'
    elif re.search(r'chats|wa-tg|wa|tg', campaign_lower):
       return 'Chats'
    elif re.search(r'clips|klips', campaign_lower):
       return 'Clips'
    elif re.search(r'mp', campaign_lower) and not re.search(r'[a-z-]+mp|mp[a-z-]+', campaign_lower):
       return 'Market-platform'
    elif re.search(r'le.ds|leadads|lead-ads', campaign_lower):
       return 'Leadads'
    elif re.search(r'traf|dinrem', campaign_lower):
       return 'Traffic'
    elif re.search(r'reach', campaign_lower):
       return 'Reach'
    elif re.search(r'quiz', campaign_lower):
        return 'Quiz'
    return None