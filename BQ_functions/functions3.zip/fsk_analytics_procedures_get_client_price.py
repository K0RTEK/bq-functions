import re

def fsk_analytics_procedures_get_client_price(object):
    object_lower = object.lower()
    if re.search(r'южная битца|(первый|1).*ленинградский|(первый|1).*лермонтовский|донской|шереметьевский|южный|ясеневский|измайловский', object_lower):
        return 'ДСК'
    if re.search(r'олимп|дружба|молод.жный', object_lower):
        return 'ФСК Калуга'
    if re.search(r'настроение|новый раменский|скай гарден|sky garden|skygarden|сколковский|спецпроект|роттердам|rotterdam|сидней сити|s.dney city|архитектор|датский квартал|режисс.р|римский|рихард|скандинавский|движение|жк для номера на лендинге|апрель|lake|сабурово|жаворонки|prime|прайм', object_lower):
        return 'ФСК'
    return f'NaN - {object}'