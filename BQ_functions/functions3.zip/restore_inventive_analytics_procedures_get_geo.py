import re

def restore_inventive_analytics_procedures_get_geo(campaign):
    campaign = campaign.lower()
    if re.search(r'msk', campaign):
        return 'Москва и МО'
    elif re.search(r'spb', campaign):
        return 'Санкт-Петербург и ЛО'
    elif re.search(r'highcr', campaign):
        return 'highcr'
    elif re.search(r'lowcr', campaign):
        return 'lowcr'
    elif re.search(r'rf', campaign):
        return 'РФ'
    else:
        return 'Прочее'
