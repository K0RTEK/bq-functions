import re

def cian_ss_agg_procedures_get_adgroup_id(source_medium, utm_campaign, utm_content, utm_term):
    if re.search(r'yandex / cpc', source_medium.lower()):
        return re.search(r'\|gid:(.+?)\|', utm_content).group(1)
    else:
        return 'NaN'