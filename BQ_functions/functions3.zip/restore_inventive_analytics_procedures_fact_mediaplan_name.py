def restore_inventive_analytics_procedures_fact_mediaplan_name(channel):
    # Проверка значений по аналогии с CASE WHEN
    if channel == 'Контекст':
        return 'Контекст'
    elif channel == 'Соцсети':
        return 'Соцсети'
    elif channel == 'Прайс-площадки':
        return 'Прайс-площадки'
    elif channel == 'Ретаргетинг':
        return 'Ретаргетинг'
    else:
        return 'NaN'

# Пример использования функции
print(restore_inventive_analytics_procedures_fact_mediaplan_name('Контекст'))        # Вернет: 'Контекст'
print(restore_inventive_analytics_procedures_fact_mediaplan_name('Соцсети'))         # Вернет: 'Соцсети'
print(restore_inventive_analytics_procedures_fact_mediaplan_name('Прайс-площадки'))  # Вернет: 'Прайс-площадки'
print(restore_inventive_analytics_procedures_fact_mediaplan_name('Ретаргетинг'))     # Вернет: 'Ретаргетинг'
print(restore_inventive_analytics_procedures_fact_mediaplan_name('Другой канал'))    # Вернет: 'NaN'
