def fsk_analytics_procedures_get_placement_price(placement_smartis: str) -> str:
    placement_smartis_lower = placement_smartis.lower()
    if 'avito' in placement_smartis_lower:
        return 'Авито'
    elif 'jcat' in placement_smartis_lower:
        return 'JCAT'
    elif 'cian' in placement_smartis_lower:
        return 'Циан'
    elif 'svetvokne' in placement_smartis_lower:
        return 'Svetvokne'
    elif 'm2' in placement_smartis_lower or 'м2' in placement_smartis_lower:
        return 'М2'
    elif 'realty' in placement_smartis_lower:
        return 'Realty'
    elif 'общее' in placement_smartis_lower:
        return 'Базы недвижимости // Общее'
    elif 'яндекс' in placement_smartis_lower:
        return 'Яндекс.Недвижимость'
    elif 'domclick' in placement_smartis_lower or 'домклик' in placement_smartis_lower:
        return 'Домклик'
    elif 'novostroy-m' in placement_smartis_lower:
        return 'Новострой-М'
    elif 'avaho' in placement_smartis_lower or 'авахо' in placement_smartis_lower:
        return 'Авахо'
    elif 'move' in placement_smartis_lower:
        return 'Move.ru'
    elif 'мирквартир' in placement_smartis_lower:
        return 'МирКвартир'
    else:
        return f'NaN - {placement_smartis}'
