import re

def fsk_analytics_procedures_get_object_comagic(campaign_name: str) -> str:
    campaign_name_lower = campaign_name.lower()

    if re.search(r'lake', campaign_name_lower):
        return 'The Lake'
    elif re.search(r'сидней|sidney|sydney', campaign_name_lower) and not re.search(r'prime|прайм', campaign_name_lower):
       return 'Сидней Сити'
    elif re.search(r'сидней|sidney|sydney', campaign_name_lower) and re.search(r'prime|прайм', campaign_name_lower):
       return 'Сидней Прайм'
    elif re.search(r'вторич', campaign_name_lower):
       return 'Вторичка'
    elif re.search(r'leningrad|ленинград', campaign_name_lower):
       return 'Первый Ленинградский'
    elif re.search(r'говорово|govorovo', campaign_name_lower):
       return 'Движение Говорово'
    elif re.search(r'гагаринский', campaign_name_lower):
       return 'Гагаринский'
    elif re.search(r'дружба', campaign_name_lower):
       return 'Дружба'
    elif re.search(r'роттердам|rotterdam', campaign_name_lower):
       return 'Роттердам'
    elif re.search(r'движение|dvizhen', campaign_name_lower) and not re.search(r'говорово|govorovo', campaign_name_lower):
       return 'Движение'
    elif re.search(r'бтл-дв|btl', campaign_name_lower):
       return 'Движение BTL'
    elif re.search(r'домодедово', campaign_name_lower):
       return 'Домодедово Парк'
    elif re.search(r'на набережной', campaign_name_lower):
       return 'На Набережной'
    elif re.search(r'флагман', campaign_name_lower):
       return 'Флагман'
    elif re.search(r'западное кунцево', campaign_name_lower):
       return 'Западное Кунцево'
    elif re.search(r'чижевского', campaign_name_lower):
       return 'Чижевского'
    elif re.search(r'лисицына', campaign_name_lower):
       return 'Лисицына'
    elif re.search(r'лухмановский', campaign_name_lower):
       return 'ТЦ Лухмановский'
    elif re.search(r'лагерь салют', campaign_name_lower):
       return 'Лагерь Салют'
    elif re.search(r'планерная', campaign_name_lower):
       return 'БО Планерная'
    elif re.search(r'магистральная', campaign_name_lower):
       return 'Магистральная'
    elif re.search(r'адмирал', campaign_name_lower):
       return 'Адмирал'
    elif re.search(r'столичный квартал', campaign_name_lower):
       return 'Столичный квартал'
    elif re.search(r'созидатель', campaign_name_lower):
       return 'ДК Созидатель'
    elif re.search(r'москворецкий', campaign_name_lower):
       return 'Москворецкий'
    elif re.search(r'юбилейный', campaign_name_lower):
       return 'Первый Юбилейный'
    elif re.search(r'garden|гарден', campaign_name_lower):
       return 'Скай Гарден'
    elif re.search(r'архитектор', campaign_name_lower):
       return 'Архитектор'
    elif re.search(r'дом на воскресенском', campaign_name_lower):
       return 'Дом на Воскресенском'
    elif re.search(r'коммерческая|коммерция|псн аренда|мясницкая', campaign_name_lower):
       return 'Коммерческая'
    elif re.search(r'кладов', campaign_name_lower):
       return 'Кладовые'
    elif re.search(r'машиноместа', campaign_name_lower):
       return 'Машиноместа'
    elif re.search(r'молод.жный', campaign_name_lower):
       return 'Молодежный'
    elif re.search(r'настроение|nastroen', campaign_name_lower):
       return 'Настроение'
    elif re.search(r'олимп', campaign_name_lower):
       return 'Олимп'
    elif re.search(r'парк апрель|aprel', campaign_name_lower):
       return 'Парк Апрель'
    elif re.search(r'шереметьевский', campaign_name_lower):
       return '1-й Шереметьевский'
    elif re.search(r'донской', campaign_name_lower):
       return '1-й Донской'
    elif re.search(r'uzhniy|южный', campaign_name_lower):
       return '1-й Южный'
    elif re.search(r'режисс.р', campaign_name_lower):
       return 'Режиссер'
    elif re.search(r'римски|rimsk', campaign_name_lower):
       return 'Римский'
    elif re.search(r'рихард|rihard', campaign_name_lower):
       return 'Рихард'
    elif re.search(r'сабурово', campaign_name_lower):
       return 'Сабурово Клаб'
    elif re.search(r'жаворонки|zhavoronk', campaign_name_lower):
       return 'Жаворонки Клаб'
    elif re.search(r'сколковский', campaign_name_lower):
       return 'Сколковский'
    elif re.search(r'поколение', campaign_name_lower):
       return 'Поколение'
    elif re.search(r'некрасовка', campaign_name_lower):
       return 'Некрасовка'
    elif re.search(r'новогиреев.кий', campaign_name_lower):
       return 'Новогиреевский'
    elif re.search(r'лермонтовский', campaign_name_lower):
       return 'Первый Лермонтовский'
    elif re.search(r'центр.2', campaign_name_lower):
       return 'Центр-2'
    elif re.search(r'центр', campaign_name_lower) and not re.search(r'центральн|центр.2', campaign_name_lower):
       return 'Центр'
    elif re.search(r'тушино', campaign_name_lower):
       return 'Новое Тушино'
    elif re.search(r'скандинавский|skandinav', campaign_name_lower):
       return 'Скандинавский'
    elif re.search(r'московский', campaign_name_lower):
       return 'Град Московский'
    elif re.search(r'датский', campaign_name_lower):
       return 'Датский'
    elif re.search(r'дыхание', campaign_name_lower):
       return 'Дом Дыхание'
    elif re.search(r'некрасовка', campaign_name_lower):
       return 'Некрасовка'
    elif re.search(r'новое измайлово', campaign_name_lower):
       return 'Новое Измайлово'
    elif re.search(r'раменский', campaign_name_lower):
       return 'Новый Раменский'
    elif re.search(r'андреевский', campaign_name_lower):
       return 'Первый Андреевский'
    elif re.search(r'солнцево', campaign_name_lower):
       return 'Солнцево'
    elif re.search(r'спецпроект|avito.*лендинг фск', campaign_name_lower):
       return 'Спецпроект'
    elif re.search(r'центральный', campaign_name_lower):
       return 'Центральный'
    elif re.search(r'битца|битце', campaign_name_lower):
       return 'Южная Битца'
    elif re.search(r'дск', campaign_name_lower):
       return 'Бренд ДСК'
    elif re.search(r'realist|реалист', campaign_name_lower):
       return 'Реалист'
    elif re.search(r'бизнес', campaign_name_lower) and not re.search(r'аутлет|outlet', campaign_name_lower):
       return 'Бизнес ФСК'
    elif re.search(r'olv.*бренд|бренд.*olv| olv', campaign_name_lower):
       return 'Бренд ФСК OLV'
    elif re.search(r'бренд фск|аутлет|outlet|фск лидер', campaign_name_lower):
       return 'Бренд ФСК'
    elif campaign_name in [
        'MG | Контекст Бренд | Яндекс Директ |',
        'MG | Контекст Сеть | Яндекс Директ |',
        'MG | Соц сети | Прозвон Lead2Call',
        'MG_Instagram'
    ]:
        return 'Невозможно определить Объект'

    return 'NaN'
