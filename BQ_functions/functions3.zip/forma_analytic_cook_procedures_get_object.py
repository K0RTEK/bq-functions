import re

def forma_analytic_cook_procedures_get_object(parameter):
    if re.search(r'(^|.)(republic)($|.)', parameter.lower()):
        return 'Republic'
    elif re.search(r'(^|.)(moments)($|.)', parameter.lower()):
        return 'Moments'
    elif re.search(r'(^|.)(mono)($|.)', parameter.lower()):
        return 'Mono'
    elif re.search(r'(^|.)(forma)($|.)', parameter.lower()):
        return 'Brand FORMA'
    return 'Не определено'