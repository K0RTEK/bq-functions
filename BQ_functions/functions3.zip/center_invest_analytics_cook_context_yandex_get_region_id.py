import re

def center_invest_analytics_cook_context_yandex_get_region_id(date, utm_source, utm_medium, utm_campaign, utm_content, utm_term):
    patterns = [
        r"\|reg:(\d+)\_", r"\|reg:(\d+)\|", r"\|reg\|(\d+)\|", r"%7creg:(\d+)\_", r"reg:(\d+)\_"]
    return next((match for pattern in patterns if (match := re.search(pattern, utm_content))), None)
