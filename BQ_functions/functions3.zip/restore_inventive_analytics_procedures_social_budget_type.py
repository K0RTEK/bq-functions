import re

def restore_inventive_analytics_procedures_social_budget_type(campaign):
    campaign = campaign.lower()
    if re.search(r'_m_', campaign):
        return 'основной'
    else:
        return 'NaN'
