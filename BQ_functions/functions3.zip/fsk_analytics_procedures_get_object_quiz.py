import re

def fsk_analytics_procedures_get_object_quiz(placement: str, quiz_name: str, contact_phone: str) -> str:
    quiz_name_lower = quiz_name.lower()

    if placement == 'vk':
        if re.search(r'7999999999|7911111111|700000000|9111111111', contact_phone):
            return 'Тест'
        elif re.search(r'br.*olv', quiz_name_lower):
           return 'Бренд ФСК OLV'
        elif re.search(r'br.*business', quiz_name_lower) and not re.search(r'outlet', quiz_name_lower):
           return 'Бизнес ФСК'
        elif re.search(r'br|fskmain', quiz_name_lower) and not re.search(r'olv|business|outlet', quiz_name_lower):
           return 'Бренд ФСК'
        elif re.search(r'fsk-outlet', quiz_name_lower):
           return 'ФСК Аутлет'
        elif re.search(r'nstr', quiz_name_lower):
           return 'Настроение'
        elif re.search(r'rezh', quiz_name_lower):
           return 'Режиссер'
        elif re.search(r'rim', quiz_name_lower) and not re.search(r'prime', quiz_name_lower):
           return 'Римский'
        elif re.search(r'rih', quiz_name_lower):
           return 'Рихард'
        elif re.search(r'сабурово|saburovo', quiz_name_lower):
           return 'Сабурово Клаб'
        elif re.search(r'zhavoron|жаворон', quiz_name_lower):
           return 'Жаворонки Клаб'
        elif re.search(r'sidn', quiz_name_lower) and not re.search(r'prime', quiz_name_lower):
           return 'Сидней Сити'
        elif re.search(r'prime', quiz_name_lower):
           return 'Сидней Прайм'
        elif re.search(r'gard', quiz_name_lower):
           return 'Скай Гарден'
        elif re.search(r'skol', quiz_name_lower):
           return 'Сколковский'
        elif re.search(r'olimp|olp', quiz_name_lower):
           return 'Олимп'
        elif re.search(r'molode|mld', quiz_name_lower):
           return 'Молодежный'
        elif re.search(r'aprel', quiz_name_lower):
           return 'Парк Апрель'
        elif re.search(r'sheremet|шеремет', quiz_name_lower):
           return '1-й Шереметьевский'
        elif re.search(r'lake', quiz_name_lower):
            return 'The Lake'
        return f'NaN - {quiz_name}'

    elif placement == 'mt':
        if re.search(r'7999999999|7911111111|700000000', contact_phone):
            return 'Тест'
        elif re.search(r'br.*olv', quiz_name_lower):
          return 'Бренд ФСК OLV'
        elif re.search(r'br.*business', quiz_name_lower) and not re.search(r'outlet', quiz_name_lower):
          return 'Бизнес ФСК'
        elif re.search(r'br|fskmain', quiz_name_lower) and not re.search(r'olv|business|outlet', quiz_name_lower):
          return 'Бренд ФСК'
        elif re.search(r'fsk-outlet', quiz_name_lower):
          return 'ФСК Аутлет'
        elif re.search(r'nstr', quiz_name_lower):
          return 'Настроение'
        elif re.search(r'rezh', quiz_name_lower):
          return 'Режиссер'
        elif re.search(r'сабурово|saburovo', quiz_name_lower):
          return 'Сабурово Клаб'
        elif re.search(r'zhavoron|жаворон', quiz_name_lower):
          return 'Жаворонки Клаб'
        elif re.search(r'rim', quiz_name_lower) and not re.search(r'prime', quiz_name_lower):
          return 'Римский'
        elif re.search(r'rih', quiz_name_lower):
          return 'Рихард'
        elif re.search(r'sidn', quiz_name_lower) and not re.search(r'prime', quiz_name_lower):
          return 'Сидней Сити'
        elif re.search(r'prime', quiz_name_lower):
          return 'Сидней Прайм'
        elif re.search(r'gard', quiz_name_lower):
          return 'Скай Гарден'
        elif re.search(r'skol', quiz_name_lower):
          return 'Сколковский'
        elif re.search(r'olimp|olp', quiz_name_lower):
          return 'Олимп'
        elif re.search(r'molode|mld', quiz_name_lower):
          return 'Молодежный'
        elif re.search(r'aprel', quiz_name_lower):
          return 'Парк Апрель'
        elif re.search(r'sheremet|шеремет', quiz_name_lower):
          return '1-й Шереметьевский'
        elif re.search(r'lake', quiz_name_lower):
            return 'The Lake'
        return f'NaN - {quiz_name}'

    elif placement == 'vkr':
        if re.search(r'7999999999|7911111111|700000000|9111111111', contact_phone):
            return 'Тест'
        elif re.search(r'br.*olv', quiz_name_lower):
           return 'Бренд ФСК OLV'
        elif re.search(r'br.*business', quiz_name_lower) and not re.search(r'outlet', quiz_name_lower):
           return 'Бизнес ФСК'
        elif re.search(r'br|fskmain', quiz_name_lower) and not re.search(r'olv|business|outlet', quiz_name_lower):
           return 'Бренд ФСК'
        elif re.search(r'fsk-outlet', quiz_name_lower):
           return 'ФСК Аутлет'
        elif re.search(r'nstr', quiz_name_lower):
           return 'Настроение'
        elif re.search(r'rezh', quiz_name_lower):
           return 'Режиссер'
        elif re.search(r'сабурово|saburovo', quiz_name_lower):
           return 'Сабурово Клаб'
        elif re.search(r'zhavoron|жаворон', quiz_name_lower):
           return 'Жаворонки Клаб'
        elif re.search(r'rim', quiz_name_lower) and not re.search(r'prime', quiz_name_lower):
           return 'Римский'
        elif re.search(r'rih', quiz_name_lower):
           return 'Рихард'
        elif re.search(r'sidn', quiz_name_lower) and not re.search(r'prime', quiz_name_lower):
           return 'Сидней Сити'
        elif re.search(r'prime', quiz_name_lower):
           return 'Сидней Прайм'
        elif re.search(r'gard', quiz_name_lower):
           return 'Скай Гарден'
        elif re.search(r'skol', quiz_name_lower):
           return 'Сколковский'
        elif re.search(r'olimp|olp', quiz_name_lower):
           return 'Олимп'
        elif re.search(r'molode|mld', quiz_name_lower):
           return 'Молодежный'
        elif re.search(r'aprel', quiz_name_lower):
           return 'Парк Апрель'
        elif re.search(r'sheremet|шеремет', quiz_name_lower):
           return '1-й Шереметьевский'
        elif re.search(r'lake', quiz_name_lower):
            return 'The Lake'
        return f'NaN - {quiz_name}'

    elif placement == 'tch':
        if re.search(r'7999999999|7911111111|700000000|9111111111', contact_phone):
            return 'Тест'
        elif re.search(r'br.*olv', quiz_name_lower):
           return 'Бренд ФСК OLV'
        elif re.search(r'br.*business', quiz_name_lower) and not re.search(r'outlet', quiz_name_lower):
           return 'Бизнес ФСК'
        elif re.search(r'br|fskmain', quiz_name_lower) and not re.search(r'olv|business|outlet', quiz_name_lower):
           return 'Бренд ФСК'
        elif re.search(r'fsk-outlet', quiz_name_lower):
           return 'ФСК Аутлет'
        elif re.search(r'nstr', quiz_name_lower):
           return 'Настроение'
        elif re.search(r'rezh', quiz_name_lower):
           return 'Режиссер'
        elif re.search(r'сабурово|saburovo', quiz_name_lower):
           return 'Сабурово Клаб'
        elif re.search(r'zhavoron|жаворон', quiz_name_lower):
           return 'Жаворонки Клаб'
        elif re.search(r'rim', quiz_name_lower) and not re.search(r'prime', quiz_name_lower):
           return 'Римский'
        elif re.search(r'rih', quiz_name_lower):
           return 'Рихард'
        elif re.search(r'sidn', quiz_name_lower) and not re.search(r'prime', quiz_name_lower):
           return 'Сидней Сити'
        elif re.search(r'prime', quiz_name_lower):
           return 'Сидней Прайм'
        elif re.search(r'gard', quiz_name_lower):
           return 'Скай Гарден'
        elif re.search(r'skol', quiz_name_lower):
           return 'Сколковский'
        elif re.search(r'olimp|olp', quiz_name_lower):
           return 'Олимп'
        elif re.search(r'molode|mld', quiz_name_lower):
           return 'Молодежный'
        elif re.search(r'aprel', quiz_name_lower):
           return 'Парк Апрель'
        elif re.search(r'sheremet|шеремет', quiz_name_lower):
           return '1-й Шереметьевский'
        elif re.search(r'lake', quiz_name_lower):
            return 'The Lake'
        return f'NaN - {quiz_name}'

    elif placement == 'tiktok':
        if re.search(r'7999999999|7911111111|700000000|9111111111|77777777777|79000000000', contact_phone):
            return 'Тест'
        elif re.search(r'br.*olv', quiz_name_lower):
           return 'Бренд ФСК OLV'
        elif re.search(r'rezh', quiz_name_lower):
           return 'Режиссер'
        elif re.search(r'rim', quiz_name_lower) and not re.search(r'prime', quiz_name_lower):
           return 'Римский'
        elif re.search(r'rih', quiz_name_lower):
           return 'Рихард'
        elif re.search(r'sidn', quiz_name_lower) and not re.search(r'prime', quiz_name_lower):
           return 'Сидней Сити'
        elif re.search(r'gard', quiz_name_lower):
            return 'Скай Гарден'
        return f'NaN - {quiz_name}'

    elif placement == 'fb':
        if re.search(r'7999999999|7911111111|700000000', contact_phone):
            return 'Тест'
        elif re.search(r'br.*olv', quiz_name_lower):
           return 'Бренд ФСК OLV'
        elif re.search(r'br.*bus', quiz_name_lower):
           return 'Бизнес ФСК'
        elif re.search(r'br|fskmain', quiz_name_lower) and not re.search(r'olv|bus|outlet', quiz_name_lower):
           return 'Бренд ФСК'
        elif re.search(r'fsk-outlet', quiz_name_lower):
           return 'ФСК Аутлет'
        elif re.search(r'nstr', quiz_name_lower):
           return 'Настроение'
        elif re.search(r'rezh', quiz_name_lower):
           return 'Режиссер'
        elif re.search(r'rim', quiz_name_lower) and not re.search(r'prime', quiz_name_lower):
           return 'Римский'
        elif re.search(r'rih', quiz_name_lower):
           return 'Рихард'
        elif re.search(r'sidn', quiz_name_lower) and not re.search(r'prime', quiz_name_lower):
           return 'Сидней Сити'
        elif re.search(r'prime', quiz_name_lower):
           return 'Сидней Прайм'
        elif re.search(r'gard', quiz_name_lower):
           return 'Скай Гарден'
        elif re.search(r'skol', quiz_name_lower):
           return 'Сколковский'
        elif re.search(r'olimp|olp', quiz_name_lower):
           return 'Олимп'
        elif re.search(r'molode|mld', quiz_name_lower):
            return 'Молодежный'
        return f'NaN - {quiz_name}'

    elif placement == 'yandex':
        if re.search(r'7999999999|7911111111|700000000', contact_phone):
            return 'Тест'
        elif re.search(r' br |fsk context', quiz_name_lower) and not re.search(r'olv|bus|outlet', quiz_name_lower):
            return 'Бренд ФСК'
        return f'NaN - {quiz_name}'

    return 'placement-NaN'
