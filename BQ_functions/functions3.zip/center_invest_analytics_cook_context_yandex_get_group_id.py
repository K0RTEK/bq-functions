import re

def center_invest_analytics_cook_context_yandex_get_group_id(date, utm_source, utm_medium, utm_campaign, utm_content, utm_term):
    if utm_source is None:
        return re.search(r'\((\d+)\)$', utm_content).group(1) if re.search(r'\((\d+)\)$', utm_content) else None
    patterns = [
        r'\|gr:(\d+)\|', r'\|gid:(\d+)\|', r'%7cgr:(\d+)\%7c', r'%7cgid%7c(\d+)\%7c']
    return next((match for pattern in patterns if (match := re.search(pattern, utm_content))), None)
