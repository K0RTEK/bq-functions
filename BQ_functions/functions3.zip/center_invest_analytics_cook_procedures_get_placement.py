import re

def center_invest_analytics_cook_procedures_get_placement(parameter):
    if re.search(r'yandex', parameter.lower()):
        return 'Яндекс Директ'
    elif re.search(r'avito', parameter.lower()):
        return 'Авито'
    elif re.search(r'vk', parameter.lower()):
        return 'Вконтакте'
    return 'Не определено'