import re

def cian_ss_agg_procedures_get_channel(source_medium):
    if re.search(r'mytarget', source_medium.lower()):
        return 'Соцсети'
    elif re.search(r'vk ', source_medium.lower()):
        return 'Соцсети'
    elif re.search(r'vkr', source_medium.lower()):
        return 'Соцсети'
    elif re.search(r'yandex / cpc', source_medium.lower()):
        return 'Контекст'
    elif re.search(r'google / cpc', source_medium.lower()):
        return 'Контекст'
    elif re.search(r'soloway', source_medium.lower()):
        return 'Ретаргетинг'
    else:
        return 'channel - NaN'

def cian_ss_agg_procedures_search_net(source_medium, campaign_name, ad_name, campaign_id):
    if cian_ss_agg_procedures_get_channel(source_medium) == "Контекст":
        if re.search(r'[^_]search[_$]', campaign_name.lower()) or re.search(r'^[^_]search[_$]', ad_name.lower()):
            return 'Поиск'
        elif re.search(r'[^_]network[_$]', campaign_name.lower()) or re.search(r'^[^_]network[_$]', ad_name.lower()):
            return 'Сеть'
        return 'NaN'
    return "None"