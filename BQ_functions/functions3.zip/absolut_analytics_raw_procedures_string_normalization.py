def string_normalization(str_field):
    # Проверяем, является ли строка пустой или эквивалентной пустой
    if str_field is None or str_field.strip() in ['', '-']:
        return None
    # Приводим строку к нижнему регистру и удаляем пробелы
    return str_field.strip().lower()
