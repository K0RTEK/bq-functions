import re

def absolut_analytics_cook_procedures_get_placement(parameter):
    parameter = parameter.lower()

    if re.search(r'yandex|яндекс', parameter) and not re.search(r'realty|недвижимость|navigator|навигатор', parameter):
        return 'Яндекс Директ'
    if re.search(r'avito|авито', parameter):
        return 'Авито'
    if re.search(r'cian|циан', parameter):
        return 'Циан'
    # Add more conditions based on original SQL function
    return 'Не определено'
