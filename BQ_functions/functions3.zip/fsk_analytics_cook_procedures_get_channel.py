import re

def fsk_analytics_cook_procedures_get_channel(calltracking, traffic_source, source_engine, direct_click_order, utm_source, utm_medium, utm_campaign, utm_content, utm_term):
    if utm_source.startswith("cpa_"):
        return "Лидогенерация"
    if re.search(r'cian|циан', calltracking.lower()) or re.search(r'yandex.realty|яндекс.недвижимость', calltracking.lower()) or re.search(r'avito|авито', calltracking.lower()) or re.search(r'novostroy|новострой', calltracking.lower()):
        return 'Базы недвижимости'
    if (re.search(r'yandex', utm_source.lower()) and re.search(r'cpc', utm_medium.lower()) and (re.search(r'mg_', utm_campaign.lower()) or re.search(r'mg_', utm_content.lower()) or re.search(r'mg_', utm_term.lower()))) or (source_engine == 'Yandex: Direct' and utm_source is None and re.search(r'mg_', direct_click_order.lower())) or (re.search(r'mg|sm', calltracking.lower())) or (re.search(r'посетители без рекламной кампании|прямые заходы', calltracking.lower()) and re.search(r'yandex', utm_source.lower()) and re.search(r'mg_', utm_campaign.lower())):
        return 'Яндекс Директ'
    if traffic_source == 'Search engine traffic' and utm_source is None and utm_medium is None:
        return 'Поисковые системы'
    if traffic_source == 'Link traffic' and utm_source is None and utm_medium is None:
        return 'Переходы по ссылкам'
    if re.search(r'yandex', utm_source.lower()) and utm_medium.lower() == 'cpc' and not (re.search(r'mg_', utm_campaign.lower()) or re.search(r'mg_', utm_content.lower()) or re.search(r'mg_', utm_term.lower())):
        return 'Чужая контекстная реклама'
    return None