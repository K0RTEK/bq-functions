import re

def restore_inventive_analytics_procedures_social_logic_type(campaign):
    campaign = campaign.lower()
    if re.search(r'kw_', campaign):
        return 'ключи'
    elif re.search(r'int_|int-', campaign):
        return 'интересы'
    elif re.search(r'auto', campaign):
        return 'автоинтересы'
    elif re.search(r'dnmc_', campaign):
        return 'динрем'
    elif re.search(r'sttc_|stts_', campaign):
        return 'стат.ремаркетинг'
    elif re.search(r'lal_', campaign):
        return 'похожая аудитория'
    else:
        return 'NaN'
