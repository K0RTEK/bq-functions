def fsk_analytics_agg_procedures_get_verification(date, verify_itog, verify_itog_new):
    if date < '2022-10-01' and verify_itog == 'ЦЕЛЕВОЙ':
        return True
    elif date >= '2022-10-01' and (verify_itog_new == 'ЦЕЛЕВОЙ' or verify_itog_new == 'УСЛОВНО ЦЕЛЕВОЙ'):
        return True
    return False