import re

def fsk_analytics_agg_procedures_get_placement(date, source, medium, campaign, content, term):
    if campaign.startswith('mg_ya_') and source == 'yandex' and medium == 'cpc':
        placement = re.search(r'\|s:([^|]+)', content)
        if placement:
            return placement.group(1)
        return re.search(r'src\|([^|]+)', content.lower()).group(1)
    return None