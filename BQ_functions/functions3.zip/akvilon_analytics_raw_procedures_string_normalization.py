import re

def akvilon_analytics_raw_procedures_string_normalization(str_field):
    # Нормализует строку: удаляет лишние пробелы, преобразует в нижний регистр, возвращает NULL для пустых значений
    if str_field is None or str_field.strip() == '' or str_field.strip() == '-':
        return None
    return str_field.lower().strip()