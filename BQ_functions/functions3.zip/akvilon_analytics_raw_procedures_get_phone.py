import re

def akvilon_analytics_raw_procedures_get_phone(str_field):
    # Удаляет все символы, кроме цифр, для получения чистого номера телефона
    return re.sub(r'\..*|[^0-9]', '', str_field)