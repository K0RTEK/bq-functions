import re

def akvilon_analytics_agg_procedures_get_channel(date, utm_source, utm_medium, utm_campaign, utm_content, utm_term, ct_campaign_name):
    if (utm_source == 'yandex' and utm_medium == 'cpc') or re.search(r'контекстная реклама', ct_campaign_name.lower().strip()):
        return "Контекстная реклама"
    elif re.search(r'не указано|не заполнено', utm_source.lower().strip()) and re.search(r'не указано|не заполнено', utm_medium.lower().strip()):
        return "Органика"
    elif re.search(r'офлайн|оффлайн|offline|ofline', utm_medium.lower().strip()):
        return "Органика"
    return "Неизвестный"

def akvilon_analytics_agg_procedures_get_criterion_id(date, utm_source, utm_medium, utm_campaign, utm_content, utm_term, ct_campaign_name):
    if akvilon_analytics_agg_procedures_get_channel(date, utm_source, utm_medium, utm_campaign, utm_content, utm_term, ct_campaign_name) == "Контекстная реклама":
        return re.search(r'kw_id:([0-9]+)', utm_content.lower()).group(1) if re.search(r'kw_id:([0-9]+)', utm_content.lower()) else None
    return None
