import re

def akvilon_analytics_cook_procedures_get_verify_itog(tags):
    return bool(re.search(r'целевой', tags.lower()) and not re.search(r'нецелевой|не целевой', tags.lower()))