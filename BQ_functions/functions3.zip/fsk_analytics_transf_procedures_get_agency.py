import re

def fsk_analytics_transf_procedures_get_agency(date: str, campaign_calltracking: str, utm_source: str, utm_medium: str, utm_campaign: str, campaign_name: str, ad_group_name: str, form_name: str, object_name: str) -> str:
    form_name_lower = form_name.lower()
    campaign_calltracking_lower = campaign_calltracking.lower()
    utm_source_lower = utm_source.lower()
    utm_campaign_lower = utm_campaign.lower()
    campaign_name_lower = campaign_name.lower()
    ad_group_name_lower = ad_group_name.lower()
    object_lower = object_name.lower()

    # Условие для 'MGCom'
    if (not re.search(r'^rw|^ipro|form_name|^artsofte', form_name_lower)) or \
       campaign_calltracking_lower.startswith('mg') or \
       (campaign_calltracking_lower in ['sydney', 'skygarden', 'rimskiy', 'rihard', 'rezhiser', 'nastroenie'] and object_lower == 'программатик') or \
       utm_source_lower.startswith('mg') or \
       utm_campaign_lower.startswith('mg') or \
       campaign_name_lower.startswith('mg') or \
       ad_group_name_lower.startswith('mg'):
        return 'MGCom'

    # Условие для других 'MGCom' по object
    if re.search(r'измайловск|воскресенск|дружб|жаворонки|калуга (17|18|19|31|32)|тайфун|молод(е|ё)жный|настроение|олимп|поколение|апрель|режиссер|римский|рихард|сабурово|сидней|sydney|прайм|prime|скай.*гарден|garden|одинцово|сколковский|lake|лейк|лэйк|химкинс', object_lower):
        return 'MGCom'

    # Если ни одно из условий не выполнено, возвращаем 'Не MGCom'
    return 'Не MGCom'
