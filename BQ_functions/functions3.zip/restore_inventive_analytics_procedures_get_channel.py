def restore_inventive_analytics_procedures_get_channel(placement):
    # Проверка значений по аналогии с CASE WHEN
    if placement in ['Яндекс Директ', 'Google Ads']:
        return 'Контекст'
    elif placement in ['Facebook', 'МТ', 'Вконтакте', 'ВКР']:
        return 'Соцсети'
    elif placement == 'Прайс-площадки':
        return 'Прайс-площадки'
    elif placement in ['Соловей', 'Медиаснайпер']:
        return 'Ретаргетинг'
    elif placement in ['Яндекс РМП', 'ВКР Mobile']:
        return 'Mobile'
    else:
        return 'NaN'

# Пример использования функции
print(restore_inventive_analytics_procedures_get_channel('Яндекс Директ'))  # Вернет: 'Контекст'
print(restore_inventive_analytics_procedures_get_channel('Facebook'))       # Вернет: 'Соцсети'
print(restore_inventive_analytics_procedures_get_channel('Прайс-площадки')) # Вернет: 'Прайс-площадки'
print(restore_inventive_analytics_procedures_get_channel('Соловей'))        # Вернет: 'Ретаргетинг'
print(restore_inventive_analytics_procedures_get_channel('Яндекс РМП'))     # Вернет: 'Mobile'
print(restore_inventive_analytics_procedures_get_channel('Другой канал'))   # Вернет: 'NaN'
