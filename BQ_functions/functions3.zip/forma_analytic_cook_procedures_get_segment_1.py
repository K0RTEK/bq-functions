import re

def forma_analytic_cook_procedures_get_segment_1(date, parameter):
    if re.search(r'(_|^)srch(_|$)', parameter.lower()):
        return 'Поиск'
    elif re.search(r'(_|^)net(_|$)', parameter.lower()):
        return 'РСЯ'
    elif re.search(r'(_|^)mc-direct(_|$)', parameter.lower()):
        return 'МК'
    return None