import re

def cian_ss_agg_procedures_creo(campaign_name, ad_name, campaign_id):
    if re.search(r'cr-[a-zA-Z0-9_.+-]+$', campaign_name.lower()):
        return re.split(r'_', re.search(r'(cr-[a-zA-Z0-9_.+-]+)$', campaign_name.lower()).group(0))[0]
    elif re.search(r'cr-[a-zA-Z0-9_.+-]+$', ad_name.lower()):
        return re.split(r'_', re.search(r'(cr-[a-zA-Z0-9_.+-]+)$', ad_name.lower()).group(0))[0]
    elif re.search(r'cr:[a-zA-Z0-9_.+-]+$', campaign_name.lower()):
        return re.split(r'_', re.search(r'(cr:[a-zA-Z0-9_.+-]+)$', campaign_name.lower()).group(0))[0]
    elif re.search(r'cr:[a-zA-Z0-9_.+-]+$', ad_name.lower()):
        return re.split(r'_', re.search(r'(cr:[a-zA-Z0-9_.+-]+)$', ad_name.lower()).group(0))[0]
    elif re.search(r'_feed-', campaign_name.lower()):
        return 'Фид'
    else:
        return "creo - NaN"