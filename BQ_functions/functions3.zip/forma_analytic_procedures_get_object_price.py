import re

def forma_analytic_procedures_get_object_price(object_name):
    if re.search(r'republic', object_name.lower()):
        return 'Republic'
    elif re.search(r'moment', object_name.lower()):
        return 'Moments'
    else:
        return f'Иной проект - {object_name}'