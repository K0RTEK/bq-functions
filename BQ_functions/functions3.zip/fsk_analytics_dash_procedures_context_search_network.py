import re

def fsk_analytics_dash_procedures_context_search_network(campaign_global):
    if re.search(r'_srch|поиск', campaign_global.lower()):
        return 'Search'
    elif re.search(r'epk-direct', campaign_global.lower()):
       return 'ЕПК (единая кампания)'
    elif re.search(r'mc.direct', campaign_global.lower()):
       return 'Мастер кампаний'
    elif re.search(r'tc.direct', campaign_global.lower()):
        return 'Товарные кампании'
    return 'Network'