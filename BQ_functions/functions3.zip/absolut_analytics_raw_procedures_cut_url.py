import re

def cut_url(url, part):
    if url:
        # Приводим строку к нижнему регистру и заменяем символы
        cleaned_url = re.sub(r'($|&|=)', 'S', url.strip().lower())
        # Удаляем ненужные метки
        cleaned_url = re.sub(r'utm_sourceSS|utm_mediumSS|utm_campaignSS|utm_contentSS|utm_termSS', '', cleaned_url)
        # Ищем нужную часть
        match = re.search(rf'{part}S(.+?)S', cleaned_url)
        if match:
            return match.group(1)
    return "None"
