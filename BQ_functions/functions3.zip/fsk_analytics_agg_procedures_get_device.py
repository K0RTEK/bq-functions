import re

def fsk_analytics_agg_procedures_get_device(date, source, medium, campaign, content, term):
    if campaign.startswith('mg_ya_') and source == 'yandex' and medium == 'cpc':
        content_lower = content.lower()
        if 'dt:' in content_lower:
            return re.search(r'dt:([^|]+)', content_lower).group(1)
        return re.search(r'dvc\|([^|]+)', content_lower).group(1)
    return None