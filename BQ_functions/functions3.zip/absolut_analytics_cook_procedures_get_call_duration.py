import re

def absolut_analytics_cook_procedures_get_call_duration(call_duration):
    # Преобразуем длительность звонка в необходимый формат
    match = re.search(r'..:..:(\d+)', call_duration)
    if match:
        seconds = int(match.group(1))
        if len(call_duration) > 8 or seconds >= 60:
            minutes = seconds // 60
            seconds = seconds % 60
            formatted_time = f"0:{minutes:02d}:{seconds:02d}"
            return formatted_time
    return call_duration
