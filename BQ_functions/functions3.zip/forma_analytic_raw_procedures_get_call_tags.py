import re

def forma_analytic_raw_procedures_get_call_tags(call_tags):
    return ','.join(re.findall(r'"names":\[(.+?)\]', call_tags))