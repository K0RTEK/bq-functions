import re

def forma_analytic_cook_context_yandex_get_position(date, utm_source, utm_medium, utm_campaign, utm_content, utm_term):

    match = re.search(r'\|pos\|(.+?)\|', '|' + utm_content.replace(":", "|").strip() + '|')
    if match:
        return match.group(1)
    return None