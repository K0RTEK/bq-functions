import re

def fsk_analytics_agg_procedures_get_metrika_goal_name(goal):
    goal_lower = goal.lower()
    if re.search(r'130361575', goal_lower):
        return 'Посмотрели Акции и Скидки'
    elif re.search(r'204085729', goal_lower):
        return 'Автоцель: отправка формы'
    elif re.search(r'229295889', goal_lower):
        return 'Весь сайт. Отправлена форма'
    elif re.search(r'254559703', goal_lower):
        return 'ФСК // Посетили выбор квартир в ЖК'
    elif re.search(r'296239163', goal_lower):
        return 'Шереметьевский // Просмотр квартир'
    elif re.search(r'297423180', goal_lower):
        return 'Дружба // Посетили выбор квартир'
    elif re.search(r'180465367', goal_lower):
        return 'Молодежный // Посетили выбор квартир'
    elif re.search(r'130361446', goal_lower):
        return 'Олимп // Посетили выбор квартир'
    elif re.search(r'136794757', goal_lower):
        return 'Режиссёр // Посетили выбор квартир'
    elif re.search(r'47819251', goal_lower):
        return 'Рихард // Посетили выбор квартир'
    elif re.search(r'136708495', goal_lower):
        return 'Римский // Посетили выбор квартир'
    elif re.search(r'226780776', goal_lower):
        return 'Скай Гарден // Посетили выбор квартир'
    elif re.search(r'151241110', goal_lower):
        return 'Сидней Сити // Посетили выбор квартир'
    elif re.search(r'251222896', goal_lower):
        return 'Сидней Прайм // Посетили выбор квартир'
    elif re.search(r'297423123', goal_lower):
        return 'THE LAKE // Посетили выбор квартир'
    elif re.search(r'130290436', goal_lower):
        return 'Парк Апрель // Посетили выбор квартир'
    elif re.search(r'297423133', goal_lower):
        return 'Сабурово Клаб // Посетили выбор квартир'
    elif re.search(r'296355203', goal_lower):
        return 'Жаворонки // Посетили выбор квартир'
    return f'NaN - {goal}'