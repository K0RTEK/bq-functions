import re

def restore_inventive_analytics_procedures_get_traffic_type(campaign):
    campaign = campaign.lower()
    if re.search(r'_p_', campaign):
        return 'Поиск'
    elif re.search(r'_s_', campaign):
        return 'Сеть'
    else:
        return 'Прочее'
