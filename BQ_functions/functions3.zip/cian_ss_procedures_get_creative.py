import re

def cian_ss_procedures_get_creative(campaign_name, ad_name):
    if re.search(r'cr:[^_]+', ad_name.lower()):
        return re.search(r'cr:[^_]+', ad_name.lower()).group(0)
    elif re.search(r'cr:[^_]+', campaign_name.lower()):
        return re.search(r'cr:[^_]+', campaign_name.lower()).group(0)
    else:
        return 'NaN'