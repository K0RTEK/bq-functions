import re

def restore_inventive_analytics_procedures_social_logic(campaign):
    campaign = campaign.lower()
    if re.search(r'ret_', campaign):
        return 'ретаргет'
    elif re.search(r'dir_', campaign):
        return 'прямая'
    else:
        return 'NaN'
