def forma_analytic_cook_procedures_get_verify_itog(date, tags):
    date_threshold = '2024-06-01'

    if date < date_threshold and 'целевой_б24' in tags.lower() and 'уже не актуально' not in tags.lower():
        return True
    elif date >= date_threshold and 'целевой_б24' in tags.lower():
        return True
    else:
        return False
