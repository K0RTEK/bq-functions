import re

def cian_ss_agg_procedures_get_channel(source_medium):
    if re.search(r'mytarget', source_medium.lower()):
        return 'Соцсети'
    elif re.search(r'vk ', source_medium.lower()):
        return 'Соцсети'
    elif re.search(r'vkr', source_medium.lower()):
        return 'Соцсети'
    elif re.search(r'yandex / cpc', source_medium.lower()):
        return 'Контекст'
    elif re.search(r'google / cpc', source_medium.lower()):
        return 'Контекст'
    elif re.search(r'soloway', source_medium.lower()):
        return 'Ретаргетинг'
    else:
        return 'channel - NaN'

def cian_ss_agg_procedures_type_camp(source_medium, campaign_name, ad_name, campaign_id):
    channel = cian_ss_agg_procedures_get_channel(source_medium)
    if channel == "Контекст":
        if re.search(r'^br[ae]nd|_br[ae]nd_|_br[ae]nd$', campaign_name.lower()) or re.search(r'^br[ae]nd|_br[ae]nd_|_br[ae]nd$', ad_name.lower()):
            return 'Бренд'
        return 'Небренд'
    elif channel == "Соцсети":
        if re.search(r'^new|_new_|_new$', campaign_name.lower()) or re.search(r'^new|_new_|_new$', ad_name.lower()):
            return 'Новая'
        elif re.search(r'^rtg|_rtg_|_rtg$', campaign_name.lower()) or re.search(r'^rtg|_rtg_|_rtg$', ad_name.lower()):
            return 'Ретаргет'
        elif re.search(r'^hybrid|_hybrid_|_hybrid$', campaign_name.lower()) or re.search(r'^hybrid|_hybrid_|_hybrid$', ad_name.lower()):
            return 'Гибрид'
        return "type_camp - NaN"
    return "type_camp - NaN"