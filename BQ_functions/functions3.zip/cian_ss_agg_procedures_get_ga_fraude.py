def cian_ss_agg_procedures_get_ga_fraude(timeOnSite, transactions):
    if (timeOnSite <= 61 and transactions > 6) or (61 < timeOnSite <= 2076 and transactions > 14):
        return True
    else:
        return None