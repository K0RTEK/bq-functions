import re

def center_invest_analytics_cook_context_yandex_get_source_type(date, utm_source, utm_medium, utm_campaign, utm_content, utm_term):
    if re.search(r'src\|context|src%7ccontext|st:context', utm_content):
        return 'ad_network'
    elif re.search(r'src\|search|src%7csearch|st:search', utm_content):
        return 'search'
    return None