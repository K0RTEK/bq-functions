import re

def forma_analytic_agg_procedures_get_work_placements(date, source, medium, campaign, content, term, ct_campaign_name):

    if re.search(r'контекстная реклама', ct_campaign_name.lower()) and re.search(r'яндекс.директ', ct_campaign_name.lower()):
        return 'Яндекс Директ'
    elif source == 'yandex' and medium == 'cpc':
        return 'Яндекс Директ'
    return None