import re

def cian_ss_procedures_get_group_new_ret(campaign_name):
    campaign_name_lower = campaign_name.lower()

    if re.search(r'_drtg_|_rtg_', campaign_name_lower):
        return 'Ретаргетинг'
    elif re.search(r'_new_', campaign_name_lower):
        return 'Новая'
    else:
        return f"NaN - {campaign_name}"