def fsk_analytics_procedures_get_placement_quiz(quiz_name: str, utm_source: str, name_length: str) -> str:
    utm_source_lower = utm_source.lower()
    quiz_name_lower = quiz_name.lower()

    if 'mytarget' in utm_source_lower or 'mt' in utm_source_lower:
        return 'mt' if name_length == 'shortname' else 'MyTarget'
    elif 'vkontakte' in utm_source_lower or ('vk' in utm_source_lower and 'vk.*reklama' not in utm_source_lower):
        return 'vk' if name_length == 'shortname' else 'Vkontakte'
    elif 'vk.*reklama' in utm_source_lower or 'vkads' in utm_source_lower or 'vkreklama' in utm_source_lower:
        return 'vkr' if name_length == 'shortname' else 'VK Reklama'
    elif 'tiktok' in utm_source_lower:
        return 'tiktok' if name_length == 'shortname' else 'Tik-tok'
    elif 'yandex' in utm_source_lower:
        return 'yandex' if name_length == 'shortname' else 'Яндекс.Директ'
    elif 'google' in utm_source_lower:
        return 'google' if name_length == 'shortname' else 'Google Ads'
    elif 'fb' in utm_source_lower or 'facebook' in utm_source_lower:
        return 'fb' if name_length == 'shortname' else 'Facebook'
    else:
        if 'fb.*mt' in quiz_name_lower or 'mt' in quiz_name_lower or 'мт' in quiz_name_lower:
            return 'mt' if name_length == 'shortname' else 'MyTarget'
        elif 'fb.*vk' in quiz_name_lower or 'vk' in quiz_name_lower or 'вк' in quiz_name_lower and 'vkr' not in quiz_name_lower and 'reklama' not in quiz_name_lower:
            return 'vk' if name_length == 'shortname' else 'Vkontakte'
        elif 'vkr' in quiz_name_lower or 'vk.*reklama' in quiz_name_lower:
            return 'vkr' if name_length == 'shortname' else 'VK Reklama'
        elif 'tenchat' in quiz_name_lower:
            return 'tch' if name_length == 'shortname' else 'Tenchat'
        elif 'tiktok' in quiz_name_lower or 'tik-tok' in quiz_name_lower:
            return 'tiktok' if name_length == 'shortname' else 'Tik-tok'
        elif 'яндекс' in quiz_name_lower or 'yandex' in quiz_name_lower:
            return 'yandex' if name_length == 'shortname' else 'Яндекс.Директ'
        elif 'google' in quiz_name_lower:
            return 'google' if name_length == 'shortname' else 'Google Ads'
        elif 'fb' in quiz_name_lower or 'facebook' in quiz_name_lower or quiz_name in [
            'FSK NSTR', 'FSK REZH', 'FSK RIH', 'FSK RIM', 'FSK BR OLV',
            'FSK BR', 'FSK BR BUS New', 'FSK SKOL', 'FSK BR BUSINESS', 'FSK BR OLV'
        ]:
            return 'fb' if name_length == 'shortname' else 'Facebook'
        else:
            return 'NaN'
