import re

def akvilon_analytics_raw_procedures_cut_url(url, part):
    # Преобразует URL и извлекает нужную часть, используя регулярные выражения
    if url:
        url_lower_trimmed = url.lower().strip()
        url_cleaned = re.sub(r'($|&|=)', 'S', url_lower_trimmed)
        url_cleaned = re.sub(r'utm_sourceSS|utm_mediumSS|utm_campaignSS|utm_contentSS|utm_termSS', '', url_cleaned)
        match = re.search(f"{part}S(.+?)S", url_cleaned)
        return match.group(1) if match else "None"
    return "None"