import re

def center_invest_analytics_cook_procedures_get_channel(calltracking, traffic_source, source_engine, direct_click_order, utm_source, utm_medium, utm_campaign, utm_content, utm_term):
    if re.search(r'yandex', utm_source) and re.search(r'cpc', utm_medium) and re.search(r'mg_', utm_campaign):
        return 'Яндекс Директ'
    elif re.search(r'google', utm_source) and re.search(r'mg_', utm_campaign):
        return 'Google Ads'
    elif traffic_source == 'Search engine traffic':
        return 'Поисковые системы'
    elif traffic_source == 'Link traffic':
        return 'Переходы по ссылкам'
    elif re.search(r'like estate|румбери', calltracking):
        return 'CPA'
    return 'Unknown'