import re

def fsk_analytics_procedures_get_object_cabinet(placement, parameter):
    placement_lower = placement.lower()
    parameter_lower = parameter.lower()

    if placement_lower == 'vkontakte':
        if re.search(r'realist', parameter_lower):
            return 'Реалист'
        elif re.search(r'brand|_soc_fsk_|soc_fsk-', parameter_lower) and re.search(r'mg_ya_|mg \| контекст',
                                                                                   parameter_lower) and not re.search(
                r'fsk_olv|brand-olv|olv-fsk|outlet', parameter_lower):
            return 'Бренд ФСК'
        elif re.search(r'business', parameter_lower) and not re.search(r'outlet', parameter_lower):
            return 'Бизнес ФСК'
        elif re.search(r'fsk(_|-)olv|brand-olv|olv(-|_)fsk', parameter_lower):
            return 'Бренд ФСК OLV'
        elif re.search(r'fsk-outlet', parameter_lower):
            return 'ФСК Аутлет'
        elif re.search(r'comm|novogir|moskovsk', parameter_lower):
            return 'Коммерческая'
        elif re.search(r'mld|molodezhn', parameter_lower):
            return 'Молодежный'
        elif re.search(r'nstr|nastr', parameter_lower):
            return 'Настроение'
        elif re.search(r'olp|olimp', parameter_lower):
            return 'Олимп'
        elif re.search(r'aprel', parameter_lower):
            return 'Парк Апрель'
        elif re.search(r'zhavoron', parameter_lower):
            return 'Жаворонки Клаб'
        elif re.search(r'sheremet', parameter_lower):
            return '1-й Шереметьевский'
        elif re.search(r'donsko', parameter_lower):
            return '1-й Донской'
        elif re.search(r'rezh', parameter_lower):
            return 'Режиссер'
        elif re.search(r'rih', parameter_lower):
            return 'Рихард'
        elif re.search(r'_rim', parameter_lower):
            return 'Римский'
        elif re.search(r'vskr|voskresensk', parameter_lower):
            return 'Дом на Воскресенском'
        elif re.search(r'saburovo-club', parameter_lower):
            return 'Сабурово Клаб'
        elif re.search(r'sidn|sydn', parameter_lower) and not re.search(r'-prime', parameter_lower):
            return 'Сидней Сити'
        elif re.search(r'sidn.*-prime|sydn.*-prime', parameter_lower):
            return 'Сидней Прайм'
        elif re.search(r'pokolen|pkl', parameter_lower):
            return 'Поколение'
        elif re.search(r'skygarden', parameter_lower):
            return 'Скай Гарден'
        elif re.search(r'skolkovsk|skl', parameter_lower):
            return 'Сколковский'
        elif re.search(r'druzhba', parameter_lower):
            return 'Дружба'
        elif re.search(r'lake', parameter_lower):
            return 'The Lake'
        return f'NaN - {parameter}'

    elif placement_lower in ('vkr', 'vk reklama'):
        if re.search(r'realist', parameter_lower):
            return 'Реалист'
        elif re.search(r'brand|_soc_fsk_|soc_fsk-', parameter_lower) and not re.search(
                r'fsk_olv|brand-olv|olv-fsk|outlet', parameter_lower):
            return 'Бренд ФСК'
        elif re.search(r'business', parameter_lower) and not re.search(r'outlet', parameter_lower):
            return 'Бизнес ФСК'
        elif re.search(r'fsk(_|-)olv|brand-olv|olv(-|_)fsk', parameter_lower):
            return 'Бренд ФСК OLV'
        elif re.search(r'fsk-outlet', parameter_lower):
            return 'ФСК Аутлет'
        elif re.search(r'comm|novogir|moskovsk', parameter_lower):
            return 'Коммерческая'
        elif re.search(r'mld|molodezhn', parameter_lower):
            return 'Молодежный'
        elif re.search(r'nstr|nastr', parameter_lower):
            return 'Настроение'
        elif re.search(r'olp|olimp', parameter_lower):
            return 'Олимп'
        elif re.search(r'aprel', parameter_lower):
            return 'Парк Апрель'
        elif re.search(r'zhavoron', parameter_lower):
            return 'Жаворонки Клаб'
        elif re.search(r'sheremet', parameter_lower):
            return '1-й Шереметьевский'
        elif re.search(r'donsko', parameter_lower):
            return '1-й Донской'
        elif re.search(r'rezh', parameter_lower):
            return 'Режиссер'
        elif re.search(r'rih', parameter_lower):
            return 'Рихард'
        elif re.search(r'_rim', parameter_lower):
            return 'Римский'
        elif re.search(r'vskr|voskresensk', parameter_lower):
            return 'Дом на Воскресенском'
        elif re.search(r'saburovo-club', parameter_lower):
            return 'Сабурово Клаб'
        elif re.search(r'sidn|sydn', parameter_lower) and not re.search(r'-prime', parameter_lower):
            return 'Сидней Сити'
        elif re.search(r'sidn.*-prime|sydn.*-prime', parameter_lower):
            return 'Сидней Прайм'
        elif re.search(r'pokolen|pkl', parameter_lower):
            return 'Поколение'
        elif re.search(r'skygarden', parameter_lower):
            return 'Скай Гарден'
        elif re.search(r'skolkovsk|skl', parameter_lower):
            return 'Сколковский'
        elif re.search(r'druzhba', parameter_lower):
            return 'Дружба'
        elif re.search(r'lake', parameter_lower):
            return 'The Lake'
        return f'NaN - {parameter}'

    elif placement_lower == 'mytarget':
        if re.search(r'realist', parameter_lower):
            return 'Реалист'
        elif re.search(r'_fsk-business_') and not re.search(r'outlet', parameter_lower):
            return 'Бизнес ФСК'
        elif re.search(r'_fsk_|brand_|_fsk-') and not re.search(r'brand_olv|brand-olv|olv-fsk|outlet', parameter_lower):
            return 'Бренд ФСК'
        elif re.search(r'fsk(_|-)olv|brand(_|-)olv|olv(-|_)fsk', parameter_lower):
            return 'Бренд ФСК OLV'
        elif re.search(r'fsk-outlet', parameter_lower):
            return 'ФСК Аутлет'
        elif re.search(r'comm', parameter_lower):
            return 'Коммерческая'
        elif re.search(r'mld|molodezhn', parameter_lower):
            return 'Молодежный'
        elif re.search(r'nastroen|nstr', parameter_lower):
            return 'Настроение'
        elif re.search(r'olimp', parameter_lower):
            return 'Олимп'
        elif re.search(r'aprel', parameter_lower):
            return 'Парк Апрель'
        elif re.search(r'zhavoron', parameter_lower):
            return 'Жаворонки Клаб'
        elif re.search(r'sheremet', parameter_lower):
            return '1-й Шереметьевский'
        elif re.search(r'donsko', parameter_lower):
            return '1-й Донской'
        elif re.search(r'pokolen', parameter_lower):
            return 'Поколение'
        elif re.search(r'rezh', parameter_lower):
            return 'Режиссер'
        elif re.search(r'rih', parameter_lower):
            return 'Рихард'
        elif re.search(r'_rim', parameter_lower):
            return 'Римский'
        elif re.search(r'saburovo-club', parameter_lower):
            return 'Сабурово Клаб'
        elif re.search(r'sidn|sydn', parameter_lower) and not re.search(r'-prime', parameter_lower):
            return 'Сидней Сити'
        elif re.search(r'sidn.*-prime|sydn.*-prime', parameter_lower):
            return 'Сидней Прайм'
        elif re.search(r'skl|skolkovsk', parameter_lower):
            return 'Сколковский'
        elif re.search(r'voskresensk', parameter_lower):
            return 'Дом на Воскресенском'
        elif re.search(r'skygarden', parameter_lower):
            return 'Скай Гарден'
        elif re.search(r'druzhba', parameter_lower):
            return 'Дружба'
        elif re.search(r'lake', parameter_lower):
            return 'The Lake'
        return f'NaN - {parameter}'

    elif placement_lower == 'tiktok':
        if re.search(r'realist', parameter_lower):
            return 'Реалист'
        elif re.search(r'olv(-|_)fsk|brand-olv|fsk(_|-)olv', parameter_lower):
            return 'Бренд ФСК OLV'
        elif re.search(r'_soc_fsk-business_', parameter_lower):
            return 'Бизнес ФСК'
        elif re.search(r'_soc_fsk_|brand', parameter_lower) and not re.search(r'olv-fsk|brand-olv|brand-fsk_olv',
                                                                              parameter_lower):
            return 'Бренд ФСК'
        elif re.search(r'voskresensk', parameter_lower):
            return 'Дом на Воскресенском'
        elif re.search(
                r'commerc|com_|fsk_auc|_bitsa_|datsk|nekrasovka|novogirievsk|dyhan|lerm|skandinav|solncevo|centr2|centr|ramensk|moskovsk|tushino',
                parameter_lower):
            return 'Коммерческая'
        elif re.search(r'molode', parameter_lower):
            return 'Молодежный'
        elif re.search(r'nastroen|nstr', parameter_lower):
            return 'Настроение'
        elif re.search(r'olimp', parameter_lower):
            return 'Олимп'
        elif re.search(r'pkl|pokolenie', parameter_lower):
            return 'Поколение'
        elif re.search(r'rezh', parameter_lower):
            return 'Режиссер'
        elif re.search(r'_rim', parameter_lower):
            return 'Римский'
        elif re.search(r'rih', parameter_lower):
            return 'Рихард'
        elif re.search(r'sidn|sydn', parameter_lower) and not re.search(r'-prime', parameter_lower):
            return 'Сидней Сити'
        elif re.search(r'sidn.*-prime|sydn.*-prime', parameter_lower):
            return 'Сидней Прайм'
        elif re.search(r'skygarden', parameter_lower):
            return 'Скай Гарден'
        elif re.search(r'skolkovsk|_skl', parameter_lower):
            return 'Сколковский'
        elif re.search(r'druzhba', parameter_lower):
            return 'Дружба'
        elif re.search(r'lake', parameter_lower):
            return 'The Lake'
        return f'NaN - {parameter}'

    elif placement_lower == 'facebook':
        if re.search(r'realist', parameter_lower):
            return 'Реалист'
        elif re.search(r'olv(-|_)fsk|brand-olv|fsk(_|-)olv', parameter_lower):
            return 'Бренд ФСК OLV'
        elif re.search(r'_soc_fsk-business_|soc_business-fsk', parameter_lower):
            return 'Бизнес ФСК'
        elif re.search(r'_soc_fsk_|brand', parameter_lower) and not re.search(r'olv-fsk|brand-olv|brand-fsk_olv',
                                                                              parameter_lower):
            return 'Бренд ФСК'
        elif re.search(r'voskresensk', parameter_lower):
            return 'Дом на Воскресенском'
        elif re.search(
                r'commerc|com_|fsk_auc|_bitsa_|datsk|nekrasovka|novogirievsk|dyhan|lerm|skandinav|solncevo|centr2|centr|ramensk|moskovsk|tushino',
                parameter_lower):
            return 'Коммерческая'
        elif re.search(r'molode', parameter_lower):
            return 'Молодежный'
        elif re.search(r'nastroen|nstr', parameter_lower):
            return 'Настроение'
        elif re.search(r'olimp', parameter_lower):
            return 'Олимп'
        elif re.search(r'pkl|pokolenie', parameter_lower):
            return 'Поколение'
        elif re.search(r'rezh', parameter_lower):
            return 'Режиссер'
        elif re.search(r'_rim', parameter_lower):
            return 'Римский'
        elif re.search(r'rih', parameter_lower):
            return 'Рихард'
        elif re.search(r'sidn|sydn', parameter_lower) and not re.search(r'prime', parameter_lower):
            return 'Сидней Сити'
        elif re.search(r'sidn.*-prime|sydn.*-prime', parameter_lower):
            return 'Сидней Прайм'
        elif re.search(r'skygarden', parameter_lower):
            return 'Скай Гарден'
        elif re.search(r'skolkovsk|_skl', parameter_lower):
            return 'Сколковский'
        elif re.search(r'druzhba', parameter_lower):
            return 'Дружба'
        elif re.search(r'lake', parameter_lower):
            return 'The Lake'
        return f'NaN - {parameter}'

    elif placement_lower == 'yandex':
        if re.search(r'fsk-the-lake', parameter_lower):
            return 'The Lake'
        elif re.search(r'fsk-olimp-obninsk', parameter_lower):
            return 'Олимп'
        elif re.search(r'fsk-rezhisser', parameter_lower):
            return 'Режиссер'
        elif re.search(r'fsk-voskresensky', parameter_lower):
            return 'Дом на Воскресенском'
        elif re.search(r'fsk-druzhba', parameter_lower):
            return 'Дружба'
        elif re.search(r'fsk-pokolenie', parameter_lower):
            return 'Поколение'
        elif re.search(r'fsk-rihard', parameter_lower):
            return 'Рихард'
        elif re.search(r'fsk-molodezhniy', parameter_lower):
            return 'Молодежный'
        elif re.search(r'fsk-skolkovsky', parameter_lower):
            return 'Сколковский'
        elif re.search(r'ipro-fsk-nastroenie', parameter_lower):
            return 'Настроение'
        elif re.search(r'fsk-park-aprel', parameter_lower):
            return 'Парк Апрель'
        elif re.search(r'fsk-zhavoronki-club', parameter_lower):
            return 'Жаворонки Клаб'
        elif re.search(r'dsk-1sheremet', parameter_lower):
            return '1-й Шереметьевский'
        elif re.search(r'fsk-rimskiy', parameter_lower):
            return 'Римский'
        elif re.search(r'fsk-sydney-city', parameter_lower) and not re.search(r's.dn.*-prime', parameter_lower):
            return 'Сидней Сити'
        elif re.search(r'fsk-sydney-city.*s.dn.*-prime', parameter_lower):
            return 'Сидней Прайм'
        elif re.search(r'fsk-saburovo-club-mo', parameter_lower):
            return 'Сабурово Клаб'
        elif re.search(r'fsk-sky-garden', parameter_lower):
            return 'Скай Гарден'
        elif re.search(r'fsk-brand', parameter_lower):
            if re.search(r'realist', parameter_lower):
                return 'Реалист'
            elif re.search(r'olv', parameter_lower):
                return 'Бренд ФСК OLV'
            elif re.search(r'business', parameter_lower) and not re.search(r'outlet', parameter_lower):
                return 'Бизнес ФСК'
            return 'Бренд ФСК'
        return f'NaN - {parameter}'

    elif placement_lower == 'google':
        if re.search(r'ВОСКРЕСЕНСКИЙ', parameter):
            return 'Дом на Воскресенском'
        elif re.search(r'НОВОГИРЕЕВСКИЙ', parameter):
            return 'Новогиреевский'
        elif re.search(r'ДРУЖБА', parameter):
            return 'Дружба'
        elif re.search(r'ПОКОЛЕНИЕ', parameter):
            return 'Поколение'
        elif re.search(r'РИМСКИЙ', parameter):
            return 'Римский'
        elif re.search(r'РЕЖИССЁР', parameter):
            return 'Режиссер'
        elif re.search(r'МОЛОДЁЖНЫЙ', parameter):
            return 'Молодежный'
        elif re.search(r'СКОЛКОВСКИЙ', parameter):
            return 'Сколковский'
        elif re.search(r'БРЕНД ФСК', parameter):
            if re.search(r'realist', parameter_lower):
                return 'Реалист'
            elif re.search(r'olv', parameter_lower):
                return 'Бренд ФСК OLV'
            elif re.search(r'business', parameter_lower) and not re.search(r'outlet', parameter_lower):
                return 'Бизнес ФСК'
            return 'Бренд ФСК'
        elif re.search(r'СИДНЕЙ СИТИ', parameter):
          return 'Сидней Сити'
        elif re.search(r'ОЛИМП', parameter):
          return 'Олимп'
        elif re.search(r'НАСТРОЕНИЕ', parameter):
          return 'Настроение'
        elif re.search(r'РИХАРД', parameter):
          return 'Рихард'
        elif re.search(r'СКАЙ ГАРДЕН', parameter):
            return 'Скай Гарден'
        return f'NaN - {parameter}'

    elif placement_lower == 'dv360':
        if re.search(r'nastroen', parameter_lower):
            return 'Настроение'
        elif re.search(r'rikhard|rihard', parameter_lower):
           return 'Рихард'
        elif re.search(r'skolkovsk', parameter_lower):
           return 'Сколковский'
        elif re.search(r'brand|fsk lider', parameter_lower) and not re.search(r'business', parameter_lower):
           return 'Бренд ФСК'
        elif re.search(r'business', parameter_lower):
           return 'Бизнес ФСК'
        elif re.search(r'rezhis', parameter_lower):
           return 'Режиссер'
        elif re.search(r'rimsk', parameter_lower):
           return 'Римский'
        elif re.search(r'garden', parameter_lower):
           return 'Скай Гарден'
        elif re.search(r'sydn|sidn', parameter_lower):
            return 'Сидней Сити'
        return f'NaN - {parameter}'

    elif placement_lower == 'criteo':
        if parameter == 'FSK Sydney-city RU':
            return 'Сидней Сити'
        elif parameter == 'FSK Skolkovskiy':
           return 'Сколковский'
        elif parameter == 'FSK Rimskiy':
           return 'Римский'
        elif parameter == 'FSK RU Rezhisser':
           return 'Режиссер'
        elif parameter == 'Fsk RU Rihard':
            return 'Рихард'
        return f'NaN - {parameter}'

    elif placement_lower == 'upravel':
        if re.search(r'fsk // aidata // недвижимость|fsk // недвижимость|fsk // ретаргетинг',
                     parameter_lower) and not re.search(r'коммерческая недвижимость', parameter_lower):
            return 'Бренд ФСК'
        elif re.search(r'fsk // бизнес|fsk business', parameter_lower):
           return 'Бизнес ФСК'
        elif re.search(r'fsk rezhiser', parameter_lower):
           return 'Режиссер'
        elif re.search(r'коммерческая недвижимость', parameter_lower):
           return 'Коммерческая'
        elif re.search(r'sky garden|skygarden', parameter_lower):
           return 'Скай Гарден'
        elif re.search(r'sydney|сидней', parameter_lower) and not re.search(r'prime|прайм', parameter_lower):
           return 'Сидней Сити'
        elif re.search(r'sydney|сидней', parameter_lower) and re.search(r'prime|прайм', parameter_lower):
           return 'Сидней Прайм'
        elif parameter == 'FSK // January // 2021 // video':
            return 'Неопределяемый ЖК'
        return f'NaN - {parameter}'

    elif placement_lower == 'custom':
        if re.search(r'бизнес|fsk-business', parameter_lower):
            return 'Бизнес ФСК'
        elif re.search(r'garden|гарден', parameter_lower):
           return 'Скай Гарден'
        elif re.search(r'sydney|сидней', parameter_lower):
           return 'Сидней Сити'
        elif re.search(r'nastroenie', parameter_lower):
           return 'Настроение'
        elif re.search(r'rezhiser', parameter_lower):
           return 'Режиссер'
        elif re.search(r'rihard', parameter_lower):
           return 'Рихард'
        elif re.search(r'rimskiy', parameter_lower):
           return 'Римский'
        elif re.search(r'skolkovskiy', parameter_lower):
            return 'Сколковский'
        return f'NaN - {parameter}'

    elif placement_lower == 'soloway':
        if re.search(r'римский', parameter_lower):
            return 'Римский'
        elif re.search(r'сидней', parameter_lower):
           return 'Сидней Сити'
        elif re.search(r'режиссер', parameter_lower):
           return 'Режиссер'
        elif re.search(r'гарден', parameter_lower):
           return 'Скай Гарден'
        elif re.search(r'настроение', parameter_lower):
           return 'Настроение'
        elif re.search(r'рихард', parameter_lower):
            return 'Рихард'
        return f'NaN - {parameter}'

    elif placement_lower == 'mobile_vkr':
        if re.search(r'outlet', parameter_lower):
            return 'ФСК Аутлет'
        elif re.search(r'rezhis', parameter_lower):
           return 'Режиссер'
        elif re.search(r'rimsk', parameter_lower):
           return 'Римский'
        elif re.search(r'rihard', parameter_lower):
           return 'Рихард'
        elif re.search(r'sydn', parameter_lower):
           return 'Сидней Сити'
        elif re.search(r'garden', parameter_lower):
            return 'Скай Гарден'
        return f'NaN - {parameter}'

    return 'placement-NaN'
