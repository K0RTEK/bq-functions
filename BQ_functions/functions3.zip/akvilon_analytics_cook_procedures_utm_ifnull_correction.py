def akvilon_analytics_cook_procedures_utm_ifnull_correction(utm):
    if utm == 'None' or utm is None:
        return ''
    return utm.lower().strip()