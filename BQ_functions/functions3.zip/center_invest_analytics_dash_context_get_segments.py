import re

def center_invest_analytics_dash_context_get_segments(date, campaign_name):
    campaign_name = campaign_name.lower()

    if re.search(r'визитка.*бренд', campaign_name):
        return ['Бренд', 'Бренд', 'Визитка Бренд', 'Поиск']
    elif re.search(r'визитка.*не(|.*)бренд', campaign_name):
        return ['НеБренд', 'НеБренд', 'Визитка НеБренд', 'Поиск']
    elif re.search(r'визитка', campaign_name):
        return ['Визитка', 'Визитка', 'Визитка', 'Поиск']
    else:
        return None
