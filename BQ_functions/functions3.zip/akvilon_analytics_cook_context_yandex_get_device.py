import re

def akvilon_analytics_cook_context_yandex_get_device(date, utm_source, utm_medium, utm_campaign, utm_content, utm_term):
    if re.search(r'dt:m|dvc:m', utm_term.lower()) or re.search(r'dt:m|dvc:m', utm_content.lower()):
        return 'mobile'
    elif re.search(r'dt:t|dvc:t', utm_term.lower()) or re.search(r'dt:t|dvc:t', utm_content.lower()):
        return 'tablet'
    elif re.search(r'dt:c|dvc:c|desktop', utm_term.lower()) or re.search(r'dt:c|dvc:c|desktop', utm_content.lower()):
        return 'desktop'