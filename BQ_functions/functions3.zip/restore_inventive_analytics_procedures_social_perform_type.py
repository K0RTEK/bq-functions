import re

def restore_inventive_analytics_procedures_social_perform_type(campaign):
    campaign = campaign.lower()
    if re.search(r'pf_', campaign):
        return 'Перформ'
    elif re.search(r'md_', campaign):
        return 'Медийка'
    else:
        return 'NaN'
