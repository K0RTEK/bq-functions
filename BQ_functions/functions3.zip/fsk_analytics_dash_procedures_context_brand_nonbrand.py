import re

def fsk_analytics_dash_procedures_context_brand_nonbrand(campaign_global):
    if re.search(r'brand|контекст бренд', campaign_global.lower()) and not re.search(r'_net_|сеть', campaign_global.lower()):
        return 'Brand'
    return 'Non-Brand'