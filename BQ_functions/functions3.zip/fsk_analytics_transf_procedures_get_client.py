import re

def fsk_analytics_transf_procedures_get_client(object_name: str) -> str:
    object_lower = object_name.lower()

    # Проверка для 'ДСК'
    if re.search(r'южная битца|(первый|1).*ленинградский|(первый|1).*лермонтовский|донской|шереметьевский|южный|ясеневский|измайловский|химкинский|саларьевский', object_lower):
        return 'ДСК'

    # Проверка для 'ФСК Калуга'
    if re.search(r'олимп|дружба|молод.жный', object_lower):
        return 'ФСК Калуга'

    # Проверка для 'ФСК'
    if re.search(r'настроение|новый раменский|скай гарден|sky garden|skygarden|сколковский|спецпроект|роттердам|rotterdam|сидней сити|s.dney city|архитектор|датский квартал|режисс.р|римский|рихард|скандинавский|движение|жк для номера на лендинге|апрель|lake|сабурово|жаворонки|prime|прайм|амбер|amber|мартем', object_lower):
        return 'ФСК'

    # Если объект не подходит ни под одно условие, возвращаем 'NaN - объект'
    return f'NaN - {object_name}'
