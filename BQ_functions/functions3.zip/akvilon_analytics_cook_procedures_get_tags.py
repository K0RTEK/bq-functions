import re

def akvilon_analytics_cook_procedures_get_tags(tags):
    if re.search(r'names', tags.lower()):
        return re.sub(r'\{|\}|\[|\]', '', re.search(r'"names":(.*)', tags).group(1))
    return tags