import re

def cian_ss_agg_procedures_geo(campaign_name, ad_name, campaign_id):
    if re.search(r'^msk|_msk_|_msk$', campaign_name.lower()) or re.search(r'^msk|_msk_|_msk$', ad_name.lower()):
        return 'Москва'
    elif re.search(r'^mskmo|_mskmo_|_mskmo$', campaign_name.lower()) or re.search(r'^mskmo|_mskmo_|_mskmo$', ad_name.lower()):
        return 'Москва'
    # Other regions follow the same logic
    else:
        return "geo - NaN"