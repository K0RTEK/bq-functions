import re

def cian_ss_procedures_get_format(campaign_name):
    if re.search(r'_leadform', campaign_name.lower()):
        return 'lead ads'
    elif re.search(r'_multi', campaign_name.lower()):
        return 'мультиформат'
    elif re.search(r'_carousel', campaign_name.lower()):
        return 'карусель'
    else:
        return 'NaN'