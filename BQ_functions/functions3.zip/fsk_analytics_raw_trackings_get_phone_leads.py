import re


def fsk_analytics_raw_trackings_get_phone_leads(phone: str) -> str:
    # Удаляем все буквы (латиницу и кириллицу) и пробелы
    cleaned_phone = re.sub(r'[а-яёa-z ]', '', phone.lower())

    # Определяем длину строки после удаления букв и пробелов
    phone_length = len(cleaned_phone)

    # Применяем логику, аналогичную SQL-функции
    if phone_length == 11 and cleaned_phone[:2] in ['84', '89']:
        return '7' + cleaned_phone[-10:]
    elif phone_length == 10:
        return '7' + cleaned_phone
    elif phone_length == 12 and cleaned_phone.startswith('77'):
        return cleaned_phone[-11:]
    elif phone_length == 12 and cleaned_phone.startswith('789'):
        return '7' + cleaned_phone[-10:]
    elif phone_length > 12 and cleaned_phone.startswith('79'):
        return cleaned_phone[:11]
    else:
        return cleaned_phone
