import re

def forma_analytic_raw_procedures_str_num(numer):
    clean_numer = re.sub(r'\..*|[^0-9]', '', re.sub(r',', '.', re.sub(r'\.', 'pp', numer.strip())))
    if clean_numer in ['', '0', ',0', ',00', '0,00', '0,0', None]:
        return None
    return float(clean_numer)