import re

def fsk_analytics_agg_procedures_get_object(parameter):
    parameter_lower = parameter.lower()
    if re.search(r'realist', parameter_lower):
        return 'Реалист'
    elif re.search(r'business|бизнес', parameter_lower) and not re.search(r'outlet', parameter_lower):
        return 'Бизнес ФСК'
    elif re.search(r'fsk(_|-)olv|olv(-|_)fsk|brand.*olv|бренд фск.*olv|бренд olv', parameter_lower):
        return 'Бренд ФСК OLV'
    elif re.search(r'fsk-outlet|аутлет', parameter_lower):
        return 'ФСК Аутлет'
    elif re.search(r'brand|_soc_fsk_|soc_fsk-|fsk lider|бренд фск', parameter_lower) and re.search(r'^mg|fsk.*недвижимость|fsk.*ретаргетинг', parameter_lower):
        return 'Бренд ФСК'
    elif re.search(r'vskr|voskresensko|воскресенском|воскресенский', parameter_lower):
        return 'Дом на Воскресенском'
    elif re.search(r'donsko', parameter_lower):
        return '1-й Донской'
    elif re.search(r'druzhba|дружба', parameter_lower):
        return 'Дружба'
    elif re.search(r'zhavoron|жаворонки', parameter_lower):
        return 'Жаворонки Клаб'
    elif re.search(r'comm|novogir|moskovsk|коммер', parameter_lower):
        return 'Коммерческая'
    elif re.search(r'mld|molodezhn|молодежный', parameter_lower):
        return 'Молодежный'
    elif re.search(r'nstr|nastr|настроение', parameter_lower):
        return 'Настроение'
    elif re.search(r'olp|olimp|олимп', parameter_lower):
        return 'Олимп'
    elif re.search(r'aprel|парк апрель', parameter_lower):
        return 'Парк Апрель'
    elif re.search(r'pokolen|pkl|поколение', parameter_lower):
        return 'Поколение'
    elif re.search(r'rezh|ежисс', parameter_lower):
        return 'Режиссер'
    elif re.search(r'_rim|rimsk|римский', parameter_lower):
        return 'Римский'
    elif re.search(r'rih|rikh|рихард', parameter_lower):
        return 'Рихард'
    elif re.search(r'saburovo-club|сабурово', parameter_lower):
        return 'Сабурово Клаб'
    elif re.search(r'sidn.*prime|sydn.*prime|сидней прайм', parameter_lower):
        return 'Сидней Прайм'
    elif re.search(r'sidn|sydn|сидней', parameter_lower):
        return 'Сидней Сити'
    elif re.search(r'garden|гарден', parameter_lower):
        return 'Скай Гарден'
    elif re.search(r'skolkovsk|skl|сколковский', parameter_lower):
        return 'Сколковский'
    elif re.search(r'центральный', parameter_lower):
        return 'Центральный'
    elif re.search(r'sheremet|шереметьевский', parameter_lower):
        return '1-й Шереметьевский'
    elif re.search(r'lake', parameter_lower):
        return 'The Lake'
    elif re.search(r'dsk|дск', parameter_lower) and re.search(r'olv', parameter_lower):
        return 'Бренд ДСК OLV'
    elif (re.search(r'(_| |-)dsk|dsk(_| |-)| дск|дск ', parameter_lower) or parameter_lower == 'dsk') and not re.search(r'olv|bitca', parameter_lower):
        return 'Бренд ДСК'
    elif re.search(r'dvijen|dvizhen|движение', parameter_lower) and re.search(r'btl', parameter_lower):
        return 'Движение BTL'
    elif re.search(r'archite.t|arhite.t|архитектор', parameter_lower):
        return 'Архитектор'
    elif re.search(r'gagar.nsk|гагаринский', parameter_lower):
        return 'Гагаринский'
    elif re.search(r'datsk|датский', parameter_lower):
        return 'Датский квартал'
    elif re.search(r'dvijen|dvizhen|движение', parameter_lower) and not re.search(r'btl|говорово|govorovo', parameter_lower):
        return 'Движение'
    elif re.search(r'govorovo|говорово', parameter_lower):
        return 'Движение Говорово'
    elif re.search(r'domodedovo|домодедово', parameter_lower):
        return 'Домодедово Парк'
    elif re.search(r'donsko|донской', parameter_lower):
        return '1-й Донской'
    elif re.search(r'dyh_|dyhan|дыхание', parameter_lower):
        return 'Дыхание'
    elif re.search(r'moskvoreck|москворецк', parameter_lower):
        return 'Москворецкий'
    elif re.search(r'nekrasov|некрасовка', parameter_lower):
        return 'Некрасовка'
    elif re.search(r'novogireevsk|новогиреевский', parameter_lower):
        return 'Новогиреевский'
    elif re.search(r'novoetushino|novoe(-| )tushino|новое тушино', parameter_lower):
        return 'Новое Тушино'
    elif re.search(r'ramensk|раменский', parameter_lower):
        return 'Новый Раменский'
    elif re.search(r'andreevsk|андреевский', parameter_lower):
        return 'Первый Андреевский'
    elif re.search(r'le(n|rn)ingradsk|ленинградский', parameter_lower):
        return 'Первый Ленинградский'
    elif re.search(r'lermontovsk|лермонтовский|1-lerm', parameter_lower):
        return 'Первый Лермонтовский'
    elif re.search(r'юбилейный', parameter_lower):
        return 'Первый Юбилейный'
    elif re.search(r'rotterdam|роттердам', parameter_lower):
        return 'Роттердам'
    elif re.search(r'skand|скандинавский', parameter_lower):
        return 'Скандинавский'
    elif re.search(r'solncevo|солнцево', parameter_lower):
        return 'Солнцево'
    elif re.search(r'flagman|флагман', parameter_lower):
        return 'Флагман'
    elif re.search(r'centr(_|.2|2)|центр(.2|2)', parameter_lower):
        return 'Центр-2'
    elif re.search(r'bit.a|битца', parameter_lower):
        return 'Южная Битца'
    elif re.search(r'uzhniy|южный', parameter_lower):
        return '1-й Южный'
    return None