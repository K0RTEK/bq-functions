import re

def forma_analytic_cook_procedures_get_channel(calltracking, traffic_source, source_engine, direct_click_order, utm_source, utm_medium, utm_campaign, utm_content, utm_term):
    if "лидогенераторы" in calltracking.lower():
        return "Лидогенерация"
    elif re.search(r'яндекс(.|..)директ', calltracking.lower()) and not re.search(r'rtb|performance|telegram|яндекс видео_olv', calltracking.lower()):
        return "Яндекс Директ"
    elif re.search(r'google', utm_source.lower()) and re.search(r'cpc', utm_medium.lower()) and (re.search(r'mg_', utm_campaign.lower()) or re.search(r'mg_', utm_content.lower()) or re.search(r'mg_', utm_term.lower())):
        return "Google Ads"
    elif traffic_source == 'Search engine traffic' and utm_source is None and utm_medium is None:
        return "Поисковые системы"
    elif traffic_source == 'Link traffic' and utm_source is None and utm_medium is None:
        return "Переходы по ссылкам"
    elif re.search(r'yandex', utm_source.lower()):
        return "Чужая контекстная реклама"
    elif (re.search(r'vk_ads|vk_reklama|vk$', utm_source.lower()) or re.search(r'mytarget|facebook|tiktok|telegram', utm_source.lower())) and utm_medium in ['cpc', 'cpm']:
        return "Реклама в соц.сетях"
    return None