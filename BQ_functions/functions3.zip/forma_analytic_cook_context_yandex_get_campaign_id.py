import re

def forma_analytic_cook_context_yandex_get_campaign_id(date, utm_source, utm_medium, utm_campaign, utm_content, utm_term):

    match = re.search(r'\|(\d+)$', utm_campaign.strip())
    if not match:
        match = re.search(r'[0-9]{6,}', utm_campaign.strip())
    if match:
        return match.group(0)
    return None