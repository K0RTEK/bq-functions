import re

def forma_analytic_raw_procedures_str_num_v2(numer):
    return float(re.sub(r',', '.', numer.strip()))