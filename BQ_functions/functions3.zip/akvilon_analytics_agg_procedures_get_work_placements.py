import re

def akvilon_analytics_agg_procedures_get_work_placements(date, utm_source, utm_medium, utm_campaign, utm_content, utm_term, ct_campaign_name):
    if re.search(r'контекстная реклама', ct_campaign_name.lower().strip()) and re.search(r'яндекс директ', ct_campaign_name.lower().strip()):
        return 'Яндекс Директ'
    elif utm_source == 'yandex' and utm_medium == 'cpc':
        return 'Яндекс Директ'
    return None
