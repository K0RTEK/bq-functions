import re

def cian_ss_agg_procedures_b2segment(campaign_name, ad_name, campaign_id):
    if re.search(r'^b2c|_b2c_|_b2c$', campaign_name.lower()) or re.search(r'^b2c|_b2c_|_b2c$', ad_name.lower()):
        return 'b2c'
    elif re.search(r'^b2b|_b2b_|_b2b$', campaign_name.lower()) or re.search(r'^b2b|_b2b_|_b2b$', ad_name.lower()):
        return 'b2b'
    else:
        return "b2segment - NaN"