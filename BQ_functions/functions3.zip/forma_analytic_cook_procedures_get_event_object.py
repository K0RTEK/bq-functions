import re

def forma_analytic_cook_procedures_get_event_object(date, parameters):
    if any(param in parameters for param in ['dummy', 'dummy']):
        return 'placeholder'
    elif any(re.search(r'dummy', param) for param in parameters):
        return 'placeholder'
    return forma_analytic_cook_procedures_get_campaign_object(date, parameters)