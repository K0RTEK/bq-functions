import re
from datetime import date


def akvilon_analytics_agg_procedures_get_segment_1(current_date, channel, utm_campaign):
    variables_var_prgrm_channel ='Programmatic/OLV'
    variables_var_prgrm_yandex = 'Яндекс'
    variables_var_cont_channel = 'Контекстная реклама'
    # Программатик
    if channel == variables_var_prgrm_channel + variables_var_prgrm_yandex:
        if utm_campaign is None:
            return None
        elif re.search(r'video', utm_campaign.lower().strip()):
            return 'Видео'
        else:
            return 'Баннеры'

    # Яндекс Директ
    elif channel == variables_var_cont_channel:
        if current_date >= date(2023, 7, 1) and current_date <= date(2024, 1, 31):
            if re.search(r'(ya_|ya_mg_)s_indy_brand', utm_campaign.lower()) and not re.search(r'signal|mg_indy',
                                                                                              utm_campaign.lower()):
                return 'Бренд'
            elif re.search(r'(ya_|ya_mg_)s_indy_geo', utm_campaign.lower()) and not re.search(r'NONE',
                                                                                              utm_campaign.lower()):
                return 'Гео'
            elif re.search(r'(ya_|ya_mg_)s_indy_remarketing', utm_campaign.lower()) and not re.search(r'NONE',
                                                                                                      utm_campaign.lower()):
                return 'Ретаргетинг'
            elif re.search(r'(ya_|ya_mg_)s_indy_compet', utm_campaign.lower()) and not re.search(r'NONE',
                                                                                                 utm_campaign.lower()):
                return 'Конкуренты'
            elif re.search(r'(ya_|ya_mg_)s_indy_general', utm_campaign.lower()) and not re.search(r'NONE',
                                                                                                  utm_campaign.lower()):
                return 'Общие'
            elif re.search(r'(ya_|ya_mg_)s_indy_mkb', utm_campaign.lower()) and not re.search(r'NONE',
                                                                                              utm_campaign.lower()):
                return 'МКБ'
            elif re.search(r'(ya_|ya_mg_)n_indy_compet', utm_campaign.lower()) and not re.search(r'NONE',
                                                                                                 utm_campaign.lower()):
                return 'Конкуренты'
            elif re.search(r'(ya_|ya_mg_)n_indy_all', utm_campaign.lower()) and not re.search(r'test',
                                                                                              utm_campaign.lower()):
                return 'Объединенная РК'
            elif re.search(r'(ya_|ya_mg_)n_indy_all_mmo_test1', utm_campaign.lower()) and not re.search(r'NONE',
                                                                                                        utm_campaign.lower()):
                return 'Тест Аквилон'
            elif re.search(r'(ya_|ya_mg_)n_indy_all_mmo_test2', utm_campaign.lower()) and not re.search(r'NONE',
                                                                                                        utm_campaign.lower()):
                return 'Тест Аквилон'
            elif re.search(r'(ya_|ya_mg_)n_indy_remarketing', utm_campaign.lower()) and not re.search(r'NONE',
                                                                                                      utm_campaign.lower()):
                return 'Ретаргетинг'
            elif re.search(r'(ya_|ya_mg_)mc_indy', utm_campaign.lower()) and not re.search(
                    r'ya_mc_indy_feed-catalog_mmo', utm_campaign.lower()):
                return 'Мастер Кампаний'
            elif re.search(r'(ya_|ya_mg_)n_indy_interests', utm_campaign.lower()) and not re.search(r'NONE',
                                                                                                    utm_campaign.lower()):
                return 'Тест Интересы'
            elif re.search(r'(ya_|ya_mg_)s_indy_brand-gk', utm_campaign.lower()) and not re.search(r'NONE',
                                                                                                   utm_campaign.lower()):
                return 'Бренд Аквилон'
            elif re.search(r'(ya_|ya_mg_)s_indy_brand_rf', utm_campaign.lower()) and not re.search(r'NONE',
                                                                                                   utm_campaign.lower()):
                return 'Бренд Регионы'
            elif re.search(r'(ya_|ya_mg_)n_indy_all_rf', utm_campaign.lower()) and not re.search(r'NONE',
                                                                                                 utm_campaign.lower()):
                return 'Объединенная РК Регионы'
            elif re.search(r'(ya_|ya_mg_)n_indy_ipoteka_mmo', utm_campaign.lower()) and not re.search(r'NONE',
                                                                                                      utm_campaign.lower()):
                return 'Ипотека'
            elif re.search(r'(ya_|ya_mg_)s_indy_compet_mkb_mmo', utm_campaign.lower()) and not re.search(r'NONE',
                                                                                                         utm_campaign.lower()):
                return 'МКБ Конкуренты'
            elif re.search(r'(ya_|ya_mg_)mc_indy_feed-catalog_mmo', utm_campaign.lower()) and not re.search(
                    r'ya_mc_indy', utm_campaign.lower()):
                return 'Товарная кампания'
            elif re.search(r'(ya_|ya_mg_)n_indy_remarketing_rf', utm_campaign.lower()) and not re.search(r'NONE',
                                                                                                         utm_campaign.lower()):
                return 'Ретаргетинг на РФ'
            elif re.search(r'(ya_|ya_mg_)n_indy_all-mob_mmo', utm_campaign.lower()) and not re.search(r'NONE',
                                                                                                      utm_campaign.lower()):
                return 'Мобильная кампания'
            elif re.search(r'(ya_|ya_mg_)tg_indy_all_mmo', utm_campaign.lower()) and not re.search(r'NONE',
                                                                                                   utm_campaign.lower()):
                return 'Телеграм тест'
            elif re.search(r'(ya_|ya_mg_)performance_indy_all_mmo', utm_campaign.lower()) and not re.search(r'NONE',
                                                                                                            utm_campaign.lower()):
                return 'Перфоманс'

        # Обрабатываем периоды с 2024-02-01
        elif current_date >= date(2024, 2, 1):
            if re.search(r'ya_mg_performance_indy_all-new_mmo', utm_campaign.lower()) and not re.search(r'NONE',
                                                                                                        utm_campaign.lower()):
                return 'ЕПК'
            elif re.search(r'(ya_|ya_mg_)s_indy_brand', utm_campaign.lower()) and not re.search(r'NONE',
                                                                                                utm_campaign.lower()):
                return 'Бренд'
            elif re.search(r'(ya_|ya_mg_)mc_indy|ya_mg_performance_indy', utm_campaign.lower()) and not re.search(
                    r'NONE', utm_campaign.lower()):
                return 'Мастер Кампаний'
            elif re.search(r'(ya_|ya_mg_)s_indy', utm_campaign.lower()) and not re.search(r'brand',
                                                                                          utm_campaign.lower()):
                return 'Поиск'
            elif re.search(r'(ya_|ya_mg_)n_indy', utm_campaign.lower()) and not re.search(r'NONE',
                                                                                          utm_campaign.lower()):
                return 'РСЯ'
            elif re.search(r'ya_mg_s_signal_brand', utm_campaign.lower()) and not re.search(r'NONE',
                                                                                            utm_campaign.lower()):
                return 'Бренд'
            elif re.search(r'ya_mg_mc_signal', utm_campaign.lower()) and not re.search(r'NONE', utm_campaign.lower()):
                return 'Мастер Кампаний'
            elif re.search(r'ya_mg_s_signal', utm_campaign.lower()) and not re.search(r'brand', utm_campaign.lower()):
                return 'Поиск'
            elif re.search(r'ya_mg_n_signal_remarketing', utm_campaign.lower()) and not re.search(r'NONE',
                                                                                                  utm_campaign.lower()):
                return 'Ретаргетинг'
            elif re.search(r'ya_mg_n_signal', utm_campaign.lower()) and not re.search(r'remarketing',
                                                                                      utm_campaign.lower()):
                return 'РСЯ'
            elif re.search(r'ya_mg_s_beside_brand', utm_campaign.lower()) and not re.search(r'akvilon_beside_brand',
                                                                                            utm_campaign.lower()):
                return 'Бренд'
            elif re.search(r'ya_mg_mc_beside', utm_campaign.lower()) and not re.search(r'NONE', utm_campaign.lower()):
                return 'Мастер Кампаний'
            elif re.search(r'ya_mg_s_beside', utm_campaign.lower()) and not re.search(r'brand', utm_campaign.lower()):
                return 'Поиск'
            elif re.search(r'ya_mg_mkb_beside', utm_campaign.lower()):
                return 'Поиск'
            elif re.search(r'ya_mg_n_beside_remarketing', utm_campaign.lower()) and not re.search(r'NONE',
                                                                                                  utm_campaign.lower()):
                return 'Ретаргетинг'
            elif re.search(r'ya_mg_n_beside', utm_campaign.lower()):
                return 'РСЯ'
        return 'Общий'

    return 'Общий'
