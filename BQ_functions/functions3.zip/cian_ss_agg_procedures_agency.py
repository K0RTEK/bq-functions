import re

def cian_ss_agg_procedures_agency(date, campaign_name, ad_name, campaign_id):
    if date < '2024-04-15':
        return None
    elif re.search(r'(^|_)mgcom(_|$)', campaign_name.lower()):
        return 'mgcom'
    elif re.search(r'(^|_)rw(_|$)', ad_name.lower()):
        return 'realweb'
    else:
        return "agency - NaN"