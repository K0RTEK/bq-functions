import re

def akvilon_analytics_cook_procedures_get_placement(parameter):
    if re.search(r'yandex|яндекс', parameter.lower()) and not re.search(r'realty|недвижимость', parameter.lower()):
        return 'Яндекс Директ'
    elif re.search(r'avito|авито', parameter.lower()):
        return 'Авито'
    elif re.search(r'cian|циан', parameter.lower()):
        return 'Cian'
    elif re.search(r'realty.*yandex|яндекс.*недвижимость', parameter.lower()):
        return 'Яндекс.Недвижимость'
    elif re.search(r'jcat', parameter.lower()):
        return 'JCAT'
    elif re.search(r'svetvokne', parameter.lower()):
        return 'Svetvokne'
    elif re.search(r'm2|м2', parameter.lower()):
        return 'М2'
    elif re.search(r'domclick|домклик', parameter.lower()):
        return 'Домклик'
    elif re.search(r'novostroy-m', parameter.lower()):
        return 'Новострой-М'
    elif re.search(r'avaho|авахо', parameter.lower()):
        return 'Авахо'
    elif re.search(r'move', parameter.lower()):
        return 'Move.ru'
    elif re.search(r'мирквартир', parameter.lower()):
        return 'МирКвартир'

    elif re.search(r'vkr|vk reklama|vk ads|vkads', parameter.lower()):
        return 'ВКР'
    elif re.search(r'vk | вк ', parameter.lower()):
        return 'Вконтакте'
    elif re.search(r'mt|mytarget', parameter.lower()):
        return 'MyTarget'
    elif re.search(r'facebook|fb|insta', parameter.lower()):
        return 'Facebook'
    elif re.search(r'telegram', parameter.lower()):
        return 'Telegram'
    elif re.search(r'tenchat', parameter.lower()):
        return 'TenChat'
    elif re.search(r'tiktok|tik-tok', parameter.lower()):
        return 'Tik-tok'

    return 'Не определено'