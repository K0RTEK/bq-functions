import re

def forma_analytic_agg_procedures_get_region_id(date, source, medium, campaign, content, term):

    if source == 'yandex' and medium == 'cpc':
        match = re.search(r'reg\|([0-9]+)', content.lower())
        if match:
            return match.group(1)
    return None