import re

def fsk_analytics_cook_procedures_get_verify_itog(tags):
    if re.search(r'целевой', tags.lower()) and not re.search(r'нецелевой|не целевой', tags.lower()):
        return True
    return False