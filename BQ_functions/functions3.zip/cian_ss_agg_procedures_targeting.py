import re

def cian_ss_agg_procedures_targeting(campaign_name, ad_name, campaign_id):
    for field in [campaign_name, ad_name]:
        if re.search(r'ta-[a-zA-Z0-9_.+-]+$', field.lower()):
            return re.split(r'_', re.search(r'(ta-[a-zA-Z0-9_.+-]+)$', field.lower()).group(1))[0]
        elif re.search(r'ta:[a-zA-Z0-9_.+-]+$', field.lower()):
            return re.split(r'_', re.search(r'(ta:[a-zA-Z0-9_.+-]+)$', field.lower()).group(1))[0]
    return "targeting - NaN"