import re

def fsk_analytics_agg_procedures_get_campaign_id(date, channel, placement, utm_source, utm_medium, utm_campaign, utm_content, utm_term):
    utm_content_lower = utm_content.lower()
    utm_campaign_lower = utm_campaign.lower()
    if channel == 'Контекстная реклама' and placement == 'Яндекс Директ':
        if 'cid:' in utm_content_lower:
            return re.search(r'cid:([0-9]+)', utm_content_lower).group(1)
        elif 'cid|' in utm_content_lower:
            return re.search(r'cid\|([0-9]+)', utm_content_lower).group(1)
        elif '|c:' in utm_content_lower:
            return re.search(r'\|c:([0-9]+)', utm_content_lower).group(1)
        elif re.search(r'кампания.*мкб или смарт-кампания', utm_campaign_lower):
            return re.search(r'[0-9]+', utm_campaign_lower).group(0)
    elif channel == 'Реклама в соц.сетях':
        if placement == 'Facebook':
            if 'cid:' in utm_content_lower:
                return re.search(r'cid:([0-9]+)', utm_content_lower).group(1)
            elif 'cid|' in utm_content_lower:
                return re.search(r'cid\|([0-9]+)', utm_content_lower).group(1)
            elif '|c:' in utm_content_lower:
                return re.search(r'\|c:([0-9]+)', utm_content_lower).group(1)
        elif placement == 'MyTarget':
            if 'cid:' in utm_content_lower:
                return re.search(r'cid:([0-9]+)', utm_content_lower).group(1)
            elif re.search(r'cid:', utm_campaign_lower):
                return re.search(r'cid:([0-9]{5,})', utm_campaign_lower).group(1)
        elif placement == 'Vkontakte':
            if 'cid:' in utm_content_lower:
                return re.search(r'cid:([0-9]+)', utm_content_lower).group(1)
            elif re.search(r'cid:', utm_campaign_lower):
                return re.search(r'cid:([0-9]{5,})', utm_campaign_lower).group(1)
    return None