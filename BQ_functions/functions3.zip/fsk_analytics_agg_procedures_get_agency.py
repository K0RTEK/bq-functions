import re

def fsk_analytics_agg_procedures_get_agency(date, campaign_calltracking, utm_source, utm_medium, utm_campaign, campaign_name, ad_group_name, form_name, object_name):
    form_name_lower = form_name.lower()
    if not re.search(r'^rw|^ipro|form_name|^artsofte', form_name_lower) or \
        'mg%' in campaign_calltracking.lower() or \
        'mg%' in utm_source.lower() or \
        'mg%' in utm_campaign.lower() or \
        'mg%' in campaign_name.lower() or \
        'mg%' in ad_group_name.lower():
        return 'MGCom'
    elif re.search(r'воскресенск|дружб|жаворонки|калуга (17|18|19|31|32)|тайфун|молод(е|ё)жный|настроение|олимп|поколение|апрель|режиссер|римский|рихард|сабурово|сидней|прайм|prime|скай.*гарден|одинцово|сколковский|lake|лейк|лэйк', object_name.lower()):
        return 'MGCom'
    else:
        return 'Не MGCom'