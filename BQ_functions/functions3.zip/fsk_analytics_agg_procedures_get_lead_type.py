import re

def fsk_analytics_agg_procedures_get_lead_type(date, campaign_calltracking, utm_source, utm_medium, utm_campaign, campaign_cabinet):
    if utm_source in ['google', 'yandex'] and utm_medium == 'cpc':
        if re.search(r'quiz', utm_campaign.lower()) or re.search(r'quiz', campaign_cabinet.lower()) or re.search(r'яндекс директ.*quiz', campaign_calltracking.lower()):
            return 'Quiz'
        return 'Traffic'
    if re.search(r'quiz', utm_campaign.lower()) or re.search(r'quiz', campaign_cabinet.lower()) or re.search(r'quiz', campaign_calltracking.lower()):
        return 'Quiz'
    if re.search(r'lead', utm_campaign.lower()) or re.search(r'lead', campaign_calltracking.lower()):
        return 'Leadads'
    return 'Traffic'