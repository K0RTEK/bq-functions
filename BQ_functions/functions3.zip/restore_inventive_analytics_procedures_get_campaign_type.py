import re

def restore_inventive_analytics_procedures_get_campaign_type(campaign):
    # Приведение строки к нижнему регистру
    campaign = campaign.lower()

    # Проверка регулярных выражений по аналогии с CASE WHEN
    if re.search(r'brand', campaign):
        return 'Брендовая'
    elif re.search(r'cat_', campaign):
        return 'Категорийная'
    elif re.search(r'vendor', campaign):
        return 'Вендорная'
    elif re.search(r'model_hand', campaign):
        return 'Модельная'
    elif re.search(r'dsa', campaign):
        return 'ДСА'
    elif re.search(r'autotargeting', campaign):
        return 'Автотаргетинг'
    elif re.search(r'smartbanner', campaign):
        return 'Смартбаннеры'
    elif re.search(r'tovarnaya', campaign):
        return 'Товарная Кампания'
    elif re.search(r'model_k50', campaign):
        return 'к50'
    elif re.search(r'rem', campaign):
        return 'Ретаргетинг'
    elif re.search(r'artdigital', campaign):
        return 'Артдиджитал'
    elif re.search(r'model_epk|epk_all', campaign):
        return 'ЕПК'
    else:
        return 'Прочее'

# Пример использования функции
print(get_campaign_type('brand_campaign_example'))  # Вернет: 'Брендовая'
print(get_campaign_type('cat_special_offer'))       # Вернет: 'Категорийная'
print(get_campaign_type('random_campaign_name'))    # Вернет: 'Прочее'
