import re

def fsk_analytics_procedures_social_campaign_types(campaign_name: str) -> str:
    campaign_name_lower = campaign_name.lower()

    if re.search(r'magazin', campaign_name_lower):
        return 'Magazin'
    elif re.search(r'chat-landing', campaign_name_lower):
        return 'Chat-landing'
    elif re.search(r'chats|wa-tg|wa|tg', campaign_name_lower):
        return 'Chats'
    elif re.search(r'clips|klips', campaign_name_lower):
        return 'Clips'
    elif re.search(r'mp', campaign_name_lower) and not re.search(r'[a-z-]+mp|mp[a-z-]+', campaign_name_lower):
        return 'Market-platform'
    elif re.search(r'le.ds|leadads|lead-ads', campaign_name_lower):
        return 'Leadads'
    elif re.search(r'traf|dinrem', campaign_name_lower):
        return 'Traffic'
    elif re.search(r'reach', campaign_name_lower):
        return 'Reach'
    elif re.search(r'quiz', campaign_name_lower):
        return 'Quiz'
    elif campaign_name == 'NaN':
        return 'Не опознается'
    else:
        return 'NaN'
