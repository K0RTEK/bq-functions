import re

def restore_inventive_analytics_procedures_social_format(campaign):
    campaign = campaign.lower()
    if re.search(r'carusel_|pf_m_ret_dnmc_action', campaign):
        return 'Карусель'
    elif re.search(r'rs_|site_|pf_m_dir_dnmc', campaign):
        return 'Реклама сайта'
    elif re.search(r'multi_', campaign):
        return 'Мультиформат'
    elif re.search(r'nat_', campaign):
        return 'Натив'
    elif re.search(r'video', campaign):
        return 'Видео'
    elif re.search(r'dro', campaign):
        return 'ДРО'
    else:
        return 'NaN'
