def restore_inventive_analytics_procedures_mob_get_cpo(date, os_type):
    if date < '2024-05-01':
        if os_type == 'Android':
            return 5714
        elif os_type == 'IOS':
            return 5556
    elif date >= '2024-05-01':
        return 5636
