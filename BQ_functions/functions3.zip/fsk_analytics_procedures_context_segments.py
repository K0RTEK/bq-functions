import re

def fsk_analytics_procedures_context_segments(campaign):
    campaign_lower = campaign.lower()
    if re.search(r'autotargeting', campaign_lower) and not re.search(r'compet|brend', campaign_lower):
        return 'Автотаргетинг'
    elif re.search(r'invest', campaign_lower):
      return 'Инвестиции'
    elif re.search(r'audience|intent|interest', campaign_lower) and not re.search(r'prilozheniya|tec|alfabank|olv|lal|ipoteka|brend', campaign_lower):
      return 'Интересы'
    elif re.search(r'ipoteka', campaign_lower) and not re.search(r'remarketing|retargeting', campaign_lower):
      return 'Ипотека'
    elif re.search(r'1kom|2kom|3kom', campaign_lower):
      return 'Комнатность'
    elif re.search(r'compet', campaign_lower) and not re.search(r'ipoteka|rassrochka', campaign_lower):
      return 'Конкуренты'
    elif re.search(r'mobapp', campaign_lower):
      return 'Приложение'
    elif re.search(r'rassrochka', campaign_lower):
      return 'Рассрочка'
    elif re.search(r'remarketing|retargeting|olv|alfabank|posetiteli', campaign_lower):
      return 'Ретаргетинг'
    elif re.search(r'smart', campaign_lower) and not re.search(r'autotargeting|company', campaign_lower):
      return 'Смарт-баннеры'
    elif re.search(r'brand|контекст бренд', campaign_lower) and re.search(r'mg_ya_|mg \| контекст', campaign_lower) and not re.search(r'_net_', campaign_lower):
      return 'Brand'
    elif re.search(r'tec|aidata|konnektu', campaign_lower) and not re.search(r'compet|dokhod', campaign_lower):
      return 'CDP'
    elif re.search(r'discovery', campaign_lower) and not re.search(r'tec|compet|intent', campaign_lower):
      return 'Discovery'
    elif re.search(r'dsa', campaign_lower):
      return 'DSA'
    elif re.search(r'generic', campaign_lower) and not re.search(r'invest|intent|ipoteca|1com|2com|3com|compet|discovery|rassrochka|brend|tec|geo|rlsa', campaign_lower):
      return 'Generic'
    elif re.search(r'geo', campaign_lower) and not re.search(r'brend', campaign_lower):
      return 'Geo'
    elif re.search(r'lal', campaign_lower) and not re.search(r'tec|discovery|rlsa', campaign_lower):
      return 'LAL'
    elif re.search(r'rlsa', campaign_lower) and not re.search(r'tec', campaign_lower):
        return 'RLSA'
    return 'Остальное'