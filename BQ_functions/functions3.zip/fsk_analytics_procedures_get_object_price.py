import re

def fsk_analytics_procedures_get_object_price(object: str) -> str:
    object_lower = object.lower()

    if re.search(r'кладовые', object_lower):
        return 'Кладовые'
    elif re.search(r'машиноместа', object_lower):
       return 'Машиноместа'
    elif re.search(r'новогиреевский', object_lower):
       return 'Новогиреевский'
    elif re.search(r'коммерция', object_lower):
       return 'Коммерция'
    elif re.search(r'м-хаус', object_lower):
       return 'М-Хаус'
    elif re.search(r'новое тушино', object_lower):
       return 'Новое Тушино'
    elif re.search(r'вторичная', object_lower):
       return 'Вторичная недвижимость'
    elif re.search(r'флагман', object_lower):
       return 'Флагман'
    elif re.search(r'новое измайлово', object_lower):
       return 'Новое Измайлово'
    elif re.search(r'дом на воскресенском', object_lower):
       return 'Дом на Воскресенском'
    elif re.search(r'воскресенск, центральный', object_lower):
       return 'Воскресенск, Центральный'
    elif re.search(r'фск', object_lower):
       return 'ФСК'
    elif re.search(r'lake|лэйк', object_lower):
       return 'The Lake'
    elif re.search(r'архитектор', object_lower):
       return 'Архитектор'
    elif re.search(r'апрель парк|парк апрель', object_lower):
       return 'Парк Апрель'
    elif re.search(r'гагаринский', object_lower):
       return 'Гагаринский (Жуковский)'
    elif re.search(r'датский квартал', object_lower):
       return 'Датский квартал'
    elif re.search(r'движение|dvizhen', object_lower) and not re.search(r'говорово|govorovo', object_lower):
       return 'Движение'
    elif re.search(r'говорово|govorovo', object_lower):
       return 'Движение Говорово'
    elif re.search(r'дружба', object_lower):
       return 'Дружба'
    elif re.search(r'дыхание', object_lower):
       return 'Дыхание'
    elif re.search(r'молод.жный', object_lower):
       return 'Молодежный'
    elif re.search(r'настроение', object_lower):
       return 'Настроение'
    elif re.search(r'некрасовка', object_lower):
       return 'Некрасовка'
    elif re.search(r'раменский', object_lower):
       return 'Новый Раменский'
    elif re.search(r'огни.сочи', object_lower):
       return 'Огни Сочи'
    elif re.search(r'олимп', object_lower):
       return 'Олимп'
    elif re.search(r'aprel|апрель', object_lower):
       return 'Парк Апрель'
    elif re.search(r'(первый|1).*ленинградский', object_lower):
       return 'Первый Ленинградский'
    elif re.search(r'(первый|1).*лермонтовский', object_lower):
       return 'Первый Лермонтовский'
    elif re.search(r'поколение', object_lower):
       return 'Поколение'
    elif re.search(r'режисс.р', object_lower):
       return 'Режиссер'
    elif re.search(r'римский', object_lower):
       return 'Римский'
    elif re.search(r'рихард', object_lower):
       return 'Рихард'
    elif re.search(r'rotterdam|роттердам', object_lower):
       return 'Роттердам'
    elif re.search(r'sydney city|сидней', object_lower) and not re.search(r'прайм|prime', object_lower):
       return 'Сидней Сити'
    elif re.search(r'sky garden|skygarden|скайгарден|скай гарден', object_lower):
       return 'Скай Гарден'
    elif re.search(r'скандинавский', object_lower):
       return 'Скандинавский'
    elif re.search(r'сколковский', object_lower):
       return 'Сколковский'
    elif re.search(r'центр.*2', object_lower):
       return 'Центр-2'
    elif re.search(r'южная битца', object_lower):
       return 'Южная Битца'
    elif re.search(r'сабурово', object_lower):
       return 'Сабурово Клаб'
    elif re.search(r'донской', object_lower):
       return 'Первый Донской'
    elif re.search(r'шереметьевский', object_lower):
       return 'Первый Шереметьевский'
    elif re.search(r'южный', object_lower):
       return 'Первый Южный'
    elif re.search(r'жаворонки', object_lower):
       return 'Жаворонки Клаб'
    elif re.search(r'прайм|prime', object_lower):
       return 'Сидней Прайм'
    elif re.search(r'тушино-2018', object_lower):
       return 'Новое Тушино'
    elif re.search(r'молжаниново', object_lower):
       return 'Первый Ленинградский'
    elif re.search(r'калуга, дружбы ул', object_lower):
       return 'Дружба'
    elif re.search(r'калуга, воскресенский', object_lower):
       return 'Воскресенский'
    elif re.search(r'калуга 17', object_lower):
       return 'Молодежный'
    elif re.search(r'жк для номера на лендинге|спецпроект', object_lower):
       return 'Спецпроект'
    elif re.search(r'ясеневский', object_lower):
       return '1-й Ясеневский'
    elif re.search(r'измайловский|измаиловский', object_lower):
       return '1-й Измайловский'
    elif re.search(r'химкинск', object_lower):
       return 'Первый Химкинский'
    elif re.search(r'саларьев', object_lower):
       return 'Первый Саларьевский'
    elif re.search(r'амбер|amber', object_lower):
       return 'Амбер Сити'
    elif re.search(r'мартем|martem', object_lower):
        return 'Мартемьяново Клаб'

    return f'NaN - {object}'
