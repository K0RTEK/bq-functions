def forma_analytic_raw_procedures_string_normalization(str_field):
    if str_field.strip().lower() in ['', '-', None]:
        return None
    else:
        return str_field.strip().lower()