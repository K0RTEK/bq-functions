import re

def forma_analytic_raw_procedures_get_metrika_goal_name(goal):
    if re.search(r'140137726', goal.lower()):
        return '???'
    else:
        return f'NaN - {goal}'