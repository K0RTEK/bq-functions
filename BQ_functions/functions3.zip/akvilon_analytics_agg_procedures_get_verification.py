import re

def akvilon_analytics_agg_procedures_get_verification(tags):
    return bool(re.search(r"(^|(, )|,)целевой($| ,|,)", tags.lower().strip()))
