import re

def fsk_analytics_procedures_get_name_feed(name):
    name_lower = name.lower()
    if re.search(r'lake', name_lower):
        return 'The Lake'
    elif re.search(r'zoom.*неве', name_lower):
       return 'Zoom на Неве'
    elif re.search(r'zoom.*черная', name_lower):
       return 'Zoom Черная речка'
    elif re.search(r'архитектор', name_lower):
       return 'Архитектор'
    elif re.search(r'балашиха', name_lower):
       return 'Балашиха'
    elif re.search(r'гагаринский', name_lower):
       return 'Гагаринский'
    elif re.search(r'датский', name_lower):
       return 'Датский квартал'
    elif re.search(r'движение|движение.*тушино|тушино.*2018', name_lower) and not re.search(r'говорово', name_lower):
       return 'Движение'
    elif re.search(r'движение.*говорово', name_lower):
       return 'Движение Говорово'
    elif re.search(r'дом на воскресенском', name_lower):
       return 'Дом на Воскресенском'
    elif re.search(r'домодедово парк', name_lower):
       return 'Домодедово Парк'
    elif re.search(r'дружб', name_lower):
       return 'Дружба'
    elif re.search(r'дск-1', name_lower):
       return 'ДСК-1'
    elif re.search(r'дыхание', name_lower):
       return 'Дыхание'
    elif re.search(r'заречный квартал', name_lower):
       return 'Заречный квартал'
    elif re.search(r'калуга (17|18|19|31|32)|тайфун|молод(е|ё)жный', name_lower):
       return 'Молодежный'
    elif re.search(r'московский', name_lower):
       return 'Московский'
    elif re.search(r'на набережной', name_lower):
       return 'На набережной. Орехово-Зуево'
    elif re.search(r'настроение', name_lower):
       return 'Настроение'
    elif re.search(r'некрасовка', name_lower):
       return 'Некрасовка'
    elif re.search(r'новогиреевский', name_lower):
       return 'Новогиреевский'
    elif re.search(r'новое измайлово', name_lower):
       return 'Новое Измайлово'
    elif re.search(r'новое тушино', name_lower):
       return 'Новое Тушино'
    elif re.search(r'раменск', name_lower):
       return 'Новый Раменский'
    elif re.search(r'олимп', name_lower):
       return 'Олимп'
    elif re.search(r'парк апрель', name_lower):
       return 'Парк Апрель'
    elif re.search(r'первый андреевский', name_lower):
       return 'Первый Андреевский'
    elif re.search(r'пушкинский', name_lower):
       return 'Пушкинский'
    elif re.search(r'1.*ленинградский', name_lower):
       return 'Первый Ленинградский'
    elif re.search(r'1.*лермонтовский', name_lower):
       return 'Первый Лермонтовский'
    elif re.search(r'первый юбилейный', name_lower):
       return 'Первый Юбилейный'
    elif re.search(r'поколение', name_lower):
       return 'Поколение'
    elif re.search(r'режиссер', name_lower):
       return 'Режиссер'
    elif re.search(r'римский', name_lower):
       return 'Римский'
    elif re.search(r'рихард', name_lower):
       return 'Рихард'
    elif re.search(r'rotterdam', name_lower):
       return 'Роттердам'
    elif re.search(r'sydney.*city', name_lower):
       return 'Сидней Сити'
    elif re.search(r'sydney.*prime', name_lower):
       return 'Сидней Прайм'
    elif re.search(r'sky.*garden', name_lower):
       return 'Скай Гарден'
    elif re.search(r'скандинавский', name_lower):
       return 'Скандинавский'
    elif re.search(r'одинцово|сколковский', name_lower):
       return 'Сколковский'
    elif re.search(r'солнцево', name_lower):
       return 'Солнцево'
    elif re.search(r'фск.*лидер', name_lower):
       return 'ФСК'
    elif re.search(r'центр.2', name_lower):
       return 'Центр-2'
    elif re.search(r'южная битца', name_lower):
        return 'Южная Битца'
    return f'NaN - {name}'