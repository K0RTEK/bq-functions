def cian_ss_agg_procedures_str_num(numer):
    cleaned_numer = numer.strip()
    if cleaned_numer in ['', '0', ',0', ',00', '0,00', '0,0', '.0', '.00', '0.00', '0.0']:
        return None
    return float(cleaned_numer.replace(',', '.'))