import re

def get_phone(str_field):
    if str_field:
        # Удаляем все символы, кроме цифр
        return re.sub(r'\..*|[^0-9]', '', str_field)
    return ""
