import re

def center_invest_analytics_cook_context_yandex_get_criterion_id(date, utm_source, utm_medium, utm_campaign, utm_content, utm_term):
    patterns = [
        r'\|kw_id:(\d+)\|', r'\|kwd-([^|]+)\|', r'kwd-(.*?)%', r':kwd-(.*?)\|',
        r'%7ckw_id:(.*?)%']
    return next((match for pattern in patterns if (match := re.search(pattern, utm_content))), None)
