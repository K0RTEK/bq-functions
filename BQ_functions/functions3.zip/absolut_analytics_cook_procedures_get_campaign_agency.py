import re

def absolut_analytics_cook_procedures_get_campaign_agency(date, parameters):
    for param in parameters:
        if re.search(r'^mg|mg$|-mg_', param, re.IGNORECASE):
            return 'MGCom'
    return 'Other'
