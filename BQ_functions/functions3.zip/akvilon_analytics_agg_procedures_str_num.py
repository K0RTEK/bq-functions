import re

def akvilon_analytics_agg_procedures_str_num(numer):
    cleaned = re.sub(r'\..*|[^0-9,]', '', numer.replace('.', 'pp').replace(',', '.').strip())
    if cleaned in ['', '0', ',0', ',00', '0,00', '0,0', None]:
        return None
    return float(cleaned)
