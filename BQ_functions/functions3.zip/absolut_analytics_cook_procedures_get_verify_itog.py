import re

def absolut_analytics_cook_procedures_get_verify_itog(tags):
    if re.search(r'целевой', tags, re.IGNORECASE) and not re.search(r'нецелевой|не целевой', tags, re.IGNORECASE):
        return True
    return False
