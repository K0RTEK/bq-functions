import re

def absolut_analytics_cook_procedures_get_campaign_object(date, parameters):
    for param in parameters:
        if re.search(r'zuopt', param, re.IGNORECASE):
            return 'ЗУ Опт'
        elif re.search(r'omegaplaza', param, re.IGNORECASE):
            return 'Омега Плаза'
        elif re.search(r'gelendgik', param, re.IGNORECASE):
            return 'ЗУ Геленджик'
    return None
