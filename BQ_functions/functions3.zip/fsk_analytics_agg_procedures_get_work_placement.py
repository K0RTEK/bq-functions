import re

def fsk_analytics_agg_procedures_get_work_placement(group_type, date, campaign_calltracking, channel_smartis, placement_smartis, utm_source, utm_medium, utm_campaign, form_name):
    utm_source_lower = utm_source.lower()
    if utm_source == 'google' and utm_medium == 'cpc':
        if group_type == 'channel':
            return 'Контекстная реклама'
        elif group_type == 'placement':
            return 'Google Ads'
    elif utm_source == 'yandex' and utm_medium == 'cpc':
        if group_type == 'channel':
            return 'Контекстная реклама'
        elif group_type == 'placement':
            return 'Яндекс Директ'
    elif re.search(r'facebook|fb_ig|inst|_fb$', utm_source_lower) and utm_medium in ['cpc', 'cpm']:
        if group_type == 'channel':
            return 'Реклама в соц.сетях'
        elif group_type == 'placement':
            return 'Facebook'
    elif re.search(r'tiktok', utm_source_lower) and utm_medium in ['cpc', 'cpm']:
        if group_type == 'channel':
            return 'Реклама в соц.сетях'
        elif group_type == 'placement':
            return 'Tik-tok'
    elif re.search(r'telegram', utm_source_lower) and utm_medium in ['cpc', 'cpm']:
        if group_type == 'channel':
            return 'Реклама в соц.сетях'
        elif group_type == 'placement':
            return 'Telegram'
    elif re.search(r'mytarget|_mt$', utm_source_lower) and utm_medium in ['cpc', 'cpm']:
        if group_type == 'channel':
            return 'Реклама в соц.сетях'
        elif group_type == 'placement':
            return 'MyTarget'
    elif re.search(r'vk_ads|vk_reklama|_vkr_', utm_source_lower) and utm_medium in ['cpc', 'cpm']:
        if group_type == 'channel':
            return 'Реклама в соц.сетях'
        elif group_type == 'placement':
            return 'ВК Реклама'
    elif re.search(r'_vk$|^vk$|^vk_', utm_source_lower) and utm_medium in ['cpc', 'cpm']:
        if group_type == 'channel':
            return 'Реклама в соц.сетях'
        elif group_type == 'placement':
            return 'Vkontakte'
    elif re.search(r'google', form_name.lower()) or re.search(r'google.*adwords|google.*ads|google.*бренд|ipro google$', campaign_calltracking.lower()) or (channel_smartis == 'Контекстная реклама' and re.search(r'google', placement_smartis.lower())):
        if group_type == 'channel':
            return 'Контекстная реклама'
        elif group_type == 'placement':
            return 'Google Ads'
    elif re.search(r'yandex|яндекс|context', form_name.lower()) or re.search(r'яндекс', campaign_calltracking.lower()) or (channel_smartis == 'Контекстная реклама' and re.search(r'яндекс|yandex', placement_smartis.lower())):
        if group_type == 'channel':
            return 'Контекстная реклама'
        elif group_type == 'placement':
            return 'Яндекс Директ'
    elif re.search(r' fb | fb$', form_name.lower()) or re.search(r'facebook| fb |insta|fb.inst', campaign_calltracking.lower()) or (channel_smartis == 'Реклама в соц.сетях' and re.search(r'facebook|instagram', placement_smartis.lower())):
        if group_type == 'channel':
            return 'Реклама в соц.сетях'
        elif group_type == 'placement':
            return 'Facebook'
    elif re.search(r'tiktok|tik-tok', form_name.lower()) or re.search(r'tiktok|tik-tok', campaign_calltracking.lower()) or (channel_smartis == 'Реклама в соц.сетях' and re.search(r'tiktok|tik-tok', placement_smartis.lower())):
        if group_type == 'channel':
            return 'Реклама в соц.сетях'
        elif group_type == 'placement':
            return 'Tik-tok'
    elif re.search(r'telegram', campaign_calltracking.lower()) and not re.search(r'nearby', campaign_calltracking.lower()) or (channel_smartis == 'Реклама в соц.сетях' and re.search(r'telegram', placement_smartis.lower())):
        if group_type == 'channel':
            return 'Реклама в соц.сетях'
        elif group_type == 'placement':
            return 'Telegram'
    elif re.search(r'tenchat', form_name.lower()) or re.search(r'tenchat', campaign_calltracking.lower()) or (channel_smartis == 'Реклама в соц.сетях' and re.search(r'tenchat', placement_smartis.lower())):
        if group_type == 'channel':
            return 'Реклама в соц.сетях'
        elif group_type == 'placement':
            return 'TenChat'
    elif re.search(r' mt$| mt |fb.*mt| мт$| мт ', form_name.lower()) or re.search(r'mt|mytarget|target.mail| mail ', campaign_calltracking.lower()) or (channel_smartis == 'Реклама в соц.сетях' and re.search(r'mytarget', placement_smartis.lower())):
        if group_type == 'channel':
            return 'Реклама в соц.сетях'
        elif group_type == 'placement':
            return 'MyTarget'
    elif re.search(r'vkr', form_name.lower()) or re.search(r'vk reklama|vk ads|vkads', campaign_calltracking.lower()) or (channel_smartis == 'Реклама в соц.сетях' and re.search(r'vk.com', placement_smartis.lower()) and date >= '2023-05-01'):
        if group_type == 'channel':
            return 'Реклама в соц.сетях'
        elif group_type == 'placement':
            return 'ВК Реклама'
    elif re.search(r'	vk | vk$| vk | вк | вк$|fb.*vk|вконтакте', form_name.lower()) or re.search(r' vk | vk$|vkontakte|вконтакте| вк ', campaign_calltracking.lower()) or (channel_smartis == 'Реклама в соц.сетях' and re.search(r'vk.com|юла', placement_smartis.lower())):
        if group_type == 'channel':
            return 'Реклама в соц.сетях'
        elif group_type == 'placement':
            return 'Vkontakte'
    elif form_name in ['FSK BR', 'FSK BR BUS New', 'FSK BR BUSINESS', 'FSK BR OLV', 'FSK LAND черновик', 'FSK NSTR', 'FSK REZH', 'FSK REZH Черновик', 'FSK RIH', 'FSK RIM', 'FSK SKOL', 'FSK BR'] or re.search(r'social network|соц. сети|соцсети|leadads|redirect|lead-ads|quiz|трафик', campaign_calltracking.lower()):
        if group_type == 'channel':
            return 'Реклама в соц.сетях'
        elif group_type == 'placement':
            return 'Facebook'
    elif re.search(r'cpa|cpа|сра', campaign_calltracking.lower()) or (channel_smartis == 'Лидогенерация'):
        if group_type == 'channel':
            return 'Лидогенерация'
        elif group_type == 'placement':
            return placement_smartis
    elif re.search(r'programmatic|программатик|prm', campaign_calltracking.lower()) or (channel_smartis == 'Программатик'):
        if group_type == 'channel':
            return 'Программатик'
        elif group_type == 'placement':
            return placement_smartis
    return None