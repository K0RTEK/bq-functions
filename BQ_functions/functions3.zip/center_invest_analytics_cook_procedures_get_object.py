import re

def center_invest_analytics_cook_procedures_get_object(parameter):
    if re.search(r'willtower', parameter.lower()):
        return 'Will Towers'
    elif re.search(r'диалог', parameter.lower()):
        return 'Диалог'
    elif re.search(r'forest', parameter.lower()):
        return 'Forest'
    return 'Не определено'