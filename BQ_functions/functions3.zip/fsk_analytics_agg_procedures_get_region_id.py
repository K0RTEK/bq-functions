import re

def fsk_analytics_agg_procedures_get_region_id(date, source, medium, campaign, content, term):
    if campaign.startswith('mg_ya_') and source == 'yandex' and medium == 'cpc':
        region_id = re.search(r'geo:([^|]+)', content.lower())
        if region_id:
            return region_id.group(1)
        return re.search(r'reg\|([^|]+)', content.lower()).group(1)
    return None