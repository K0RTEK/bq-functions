import re

def akvilon_analytics_agg_procedures_get_target_call(call_tags):
    return bool(re.search(r'("|,| |$)mg_целевой("|,| |$)', call_tags.lower().strip()))
