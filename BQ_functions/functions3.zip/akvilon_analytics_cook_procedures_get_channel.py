import re

def akvilon_analytics_cook_procedures_get_channel(calltracking, traffic_source, source_engine, direct_click_order, utm_source, utm_medium, utm_campaign, utm_content, utm_term):
    if re.search(r'^cpa_', utm_source):
        return "Лидогенерация"
    elif re.search(r'yandex', utm_source.lower()) and re.search(r'cpc', utm_medium.lower()) and \
       (re.search(r'mg_', utm_campaign.lower()) or re.search(r'mg_', utm_content.lower()) or re.search(r'mg_', utm_term.lower())):
        return "Яндекс Директ"
    elif source_engine == 'Yandex: Direct' and utm_source is None and re.search(r'mg_', direct_click_order.lower()):
        return "Яндекс Директ"
    elif re.search(r'mg|sm', calltracking.lower()):
        return "Яндекс Директ"
    elif re.search(r'посетители без рекламной кампании|прямые заходы', calltracking.lower()) and re.search(r'yandex', utm_source.lower()) and re.search(r'mg_', utm_campaign.lower()):
        return "Яндекс Директ"
    elif traffic_source == 'Search engine traffic' and utm_source is None and utm_medium is None:
        return "Поисковые системы"
    elif traffic_source == 'Link traffic' and utm_source is None and utm_medium is None:
        return "Переходы по ссылкам"
    elif re.search(r'yandex', utm_source.lower()) and utm_medium.lower() == 'cpc' and not (re.search(r'mg_', utm_campaign.lower()) or re.search(r'mg_', utm_content.lower()) or re.search(r'mg_', utm_term.lower())):
        return "Чужая контекстная реклама"
    return None