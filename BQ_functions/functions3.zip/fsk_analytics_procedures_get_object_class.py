import re


def fsk_analytics_procedures_get_object_class(object: str) -> str:
    if re.search(r'новогиреевский', object.lower()):
        return 'Комфорт'
    elif re.search(r'м-хаус', object.lower()):
       return 'Эконом'
    elif re.search(r'новое тушино', object.lower()):
       return 'Комфорт'
    elif re.search(r'флагман', object.lower()):
       return 'Бизнес'
    elif re.search(r'новое измайлово', object.lower()):
       return 'Эконом'
    elif re.search(r'дом на воскресенском', object.lower()):
       return 'Бизнес'
    elif re.search(r'воскресенск, центральный', object.lower()):
       return 'Комфорт'
    elif re.search(r'lake', object.lower()):
       return 'Бизнес'
    elif re.search(r'архитектор', object.lower()):
       return 'Бизнес'
    elif re.search(r'апрель парк|парк апрель', object.lower()):
       return 'Комфорт'
    elif re.search(r'гагаринский', object.lower()):
       return 'Комфорт'
    elif re.search(r'датский квартал', object.lower()):
       return 'Комфорт'
    elif re.search(r'движение|dvizhen', object.lower()) and not re.search(r'говорово|govorovo', object.lower()):
       return 'Комфорт'
    elif re.search(r'говорово|govorovo', object.lower()):
       return 'Комфорт'
    elif re.search(r'дружба', object.lower()):
       return 'Комфорт'
    elif re.search(r'дыхание', object.lower()):
       return 'Бизнес'
    elif re.search(r'молод.жный', object.lower()):
       return 'Комфорт'
    elif re.search(r'настроение', object.lower()):
       return 'Комфорт'
    elif re.search(r'некрасовка', object.lower()):
       return 'Комфорт'
    elif re.search(r'раменский', object.lower()):
       return 'Бизнес'
    elif re.search(r'огни.сочи', object.lower()):
       return 'Бизнес'
    elif re.search(r'олимп', object.lower()):
       return 'Комфорт'
    elif re.search(r'aprel|апрель', object.lower()):
       return 'Комфорт'
    elif re.search(r'(первый|1).*ленинградский', object.lower()):
       return 'Комфорт'
    elif re.search(r'(первый|1).*лермонтовский', object.lower()):
       return 'Комфорт'
    elif re.search(r'поколение', object.lower()):
       return 'Комфорт'
    elif re.search(r'режисс.р', object.lower()):
       return 'Бизнес'
    elif re.search(r'римский', object.lower()):
       return 'Комфорт'
    elif re.search(r'рихард', object.lower()):
       return 'Бизнес'
    elif re.search(r'rotterdam|роттердам', object.lower()):
       return 'Бизнес'
    elif re.search(r'sydney city|сидней сити', object.lower()):
       return 'Бизнес'
    elif re.search(r'sky garden|skygarden|скайгарден|скай гарден', object.lower()):
       return 'Бизнес'
    elif re.search(r'скандинавский', object.lower()):
       return 'Комфорт'
    elif re.search(r'сколковский', object.lower()):
       return 'Комфорт'
    elif re.search(r'центр.*2', object.lower()):
       return 'Комфорт'
    elif re.search(r'южная битца', object.lower()):
       return 'Комфорт'
    elif re.search(r'сабурово', object.lower()):
       return 'Бизнес'
    elif re.search(r'донской', object.lower()):
       return 'Комфорт'
    elif re.search(r'шереметьевский', object.lower()):
       return 'Комфорт'
    elif re.search(r'южный', object.lower()):
       return 'Комфорт'
    elif re.search(r'жаворонки', object.lower()):
       return 'Комфорт'
    elif re.search(r'прайм|prime', object.lower()):
       return 'Бизнес'
    elif re.search(r'новое тушино', object.lower()):
       return 'Комфорт'
    elif re.search(r'на воскресенском', object.lower()):
       return 'Комфорт'
    elif re.search(r'(первый|1).*ясеневский', object.lower()):
       return 'Комфорт'
    elif re.search(r'(первый|1).*изма(и|й)ловский', object.lower()):
        return 'Комфорт'

    return 'NaN'
