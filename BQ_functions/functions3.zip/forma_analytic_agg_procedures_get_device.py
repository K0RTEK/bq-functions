import re

def forma_analytic_agg_procedures_get_device(date, source, medium, campaign, content, term):
    """
    Аналог функции forma-analytic.agg_procedures.get_device.
    """
    if source == 'yandex' and medium == 'cpc':
        match = re.search(r'dvc:([^|]+)', content.lower())
        if match:
            return match.group(1)
    return None