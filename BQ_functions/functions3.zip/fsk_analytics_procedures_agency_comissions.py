def fsk_analytics_procedures_agency_comissions(placement_or_channel, date):
    placement_or_channel_lower = placement_or_channel.lower()
    if placement_or_channel_lower == 'google ads':
        if date < '2021-03-01':
            return 0.1
        elif date >= '2021-03-01':
            return 0.09
        return 0
    elif placement_or_channel_lower == 'яндекс директ':
        if date < '2022-08-01':
            return 0.07
        elif date >= '2022-08-01':
            return 0
        return 0
    elif placement_or_channel_lower == 'facebook':
        if date < '2021-03-01':
            return 0.1
        elif date >= '2021-03-01':
            return 0.09
        return 0
    elif placement_or_channel_lower == 'tik-tok':
        return 0.01
    elif placement_or_channel_lower in ('vkontakte', 'vk reklama', 'mytarget'):
        return 0
    elif placement_or_channel_lower in ('лидогенерация', 'программатик', 'блоггеры'):
        return 0.01
    return 0