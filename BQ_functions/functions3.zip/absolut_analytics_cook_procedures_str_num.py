def absolut_analytics_cook_procedures_str_num(numer):
    try:
        return float(numer.replace(",", ".").strip())
    except ValueError:
        return None
