import re

def forma_analytic_procedures_get_placement_price(campaign_name):
    if re.search(r'базы.*cian.*xml|базы.*циан.*xml', campaign_name.lower()):
        return 'Циан'
    elif re.search(r'базы.*yandex.*xml|базы.*яндекс.*xml', campaign_name.lower()):
        return 'Яндекс.Недвижимость'
    elif re.search(r'базы.*avito.*xml|базы.*авито.*xml', campaign_name.lower()):
        return 'Авито'
    elif re.search(r'базы.*cat.*xml', campaign_name.lower()):
        return 'JCat'
    else:
        return f'NaN - {campaign_name}'