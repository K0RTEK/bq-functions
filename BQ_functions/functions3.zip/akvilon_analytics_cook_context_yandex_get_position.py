import re

def akvilon_analytics_cook_context_yandex_get_position(date, utm_source, utm_medium, utm_campaign, utm_content, utm_term):
    return re.search(r'\|p:(\d+)\|', utm_content.lower()) or re.search(r'\|p:(\d+)\|', utm_term.lower()) or \
           "unknown"