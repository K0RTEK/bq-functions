import re

def center_invest_analytics_cook_procedures_get_verify_itog(tags):
    if re.search(r'целевой', tags.lower()) and not re.search(r'нецелевой', tags.lower()):
        return True
    return False