import re

def akvilon_analytics_cook_context_yandex_get_agency(date, smth):
    if re.search(r'^mg', smth.strip().lower()):
        return variables_mg_var_agency_mgcom()
    else:
        return 'Not MG'