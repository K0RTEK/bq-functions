import re

def forma_analytic_agg_procedures_get_criterion_id(date, source, medium, campaign, content, term):

    if source == 'yandex' and medium == 'cpc':
        match = re.search(r'phr:([0-9]+)', content.lower())
        if match:
            return match.group(1)
    return None