import re

def forma_analytic_agg_procedures_get_campaign_name(date, source, medium, campaign, content, term):
    if source == 'yandex' and medium == 'cpc':
        match = re.search(r'([^|]+)\|', campaign)
        if match:
            return match.group(1)
    return None