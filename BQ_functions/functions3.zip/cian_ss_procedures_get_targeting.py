import re

def cian_ss_procedures_get_targeting(campaign_name):
    campaign_name_lower = campaign_name.lower()
    targeting = re.search(r'ta:[^_]+', campaign_name_lower)

    if targeting:
        return targeting.group(0)
    else:
        return 'NaN'